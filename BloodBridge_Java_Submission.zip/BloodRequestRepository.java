package com.bloodbridge.repository;

import com.bloodbridge.entity.BloodRequest;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.RequestStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface BloodRequestRepository extends JpaRepository<BloodRequest, Long> {

    /** Count by status for admin dashboard */
    long countByStatus(RequestStatus status);

    /** Count requests in active states (PENDING + UNDER_REVIEW + IN_PROGRESS) */
    @Query("SELECT COUNT(r) FROM BloodRequest r WHERE r.status IN ('PENDING', 'UNDER_REVIEW', 'IN_PROGRESS')")
    long countActive();

    /** Admin: filter by status and/or blood group */
    @Query("""
            SELECT r FROM BloodRequest r
            WHERE (:status IS NULL OR r.status = :status)
              AND (:bloodGroup IS NULL OR r.bloodGroup = :bloodGroup)
            ORDER BY r.submittedAt DESC
            """)
    Page<BloodRequest> findAllFiltered(
            @Param("status") RequestStatus status,
            @Param("bloodGroup") BloodGroup bloodGroup,
            Pageable pageable);

    /** Find requests by user ID */
    java.util.List<BloodRequest> findByUserIdOrderBySubmittedAtDesc(Long userId);
}
