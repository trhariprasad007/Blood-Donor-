package com.bloodbridge.security;

import com.bloodbridge.entity.AdminUser;
import com.bloodbridge.repository.AdminUserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Creates the initial administrator account on first startup ONLY if
 * no admin account exists yet.
 *
 * IMPORTANT: This component does NOT reset the password on every startup.
 * It only creates the account once when the database is empty.
 *
 * Configure the initial credentials via environment variables:
 *   APP_ADMIN_USERNAME (default: admin)
 *   APP_ADMIN_PASSWORD (default: Admin@123)
 *
 * Change the password after first login in a production environment.
 * Public self-registration as an administrator is not allowed.
 */
@Component
public class AdminBootstrapService {

    private static final Logger logger = LoggerFactory.getLogger(AdminBootstrapService.class);

    private final AdminUserRepository adminUserRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.admin.username:admin}")
    private String adminUsername;

    @Value("${app.admin.password:Admin@123}")
    private String adminPassword;

    public AdminBootstrapService(AdminUserRepository adminUserRepository,
                                  PasswordEncoder passwordEncoder) {
        this.adminUserRepository = adminUserRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @EventListener(ApplicationReadyEvent.class)
    @Transactional
    public void createDefaultAdminIfNeeded() {
        if (adminUserRepository.count() == 0) {
            logger.info("No administrator accounts found. Creating initial admin account: '{}'", adminUsername);

            AdminUser admin = new AdminUser();
            admin.setUsername(adminUsername);
            admin.setPasswordHash(passwordEncoder.encode(adminPassword));
            admin.setDisplayName("System Administrator");
            admin.setActive(true);

            adminUserRepository.save(admin);

            logger.info("Initial admin account created. Username: '{}'. " +
                    "Please change the password after first login.", adminUsername);
        } else {
            logger.debug("Admin account(s) already exist. Skipping bootstrap.");
        }
    }
}
