package com.bloodbridge.repository;

import com.bloodbridge.entity.BloodBank;
import com.bloodbridge.entity.BloodStock;
import com.bloodbridge.enums.BloodGroup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BloodStockRepository extends JpaRepository<BloodStock, Long> {

    /** Find a specific stock record for a bank and blood group */
    Optional<BloodStock> findByBloodBankAndBloodGroup(BloodBank bloodBank, BloodGroup bloodGroup);

    Optional<BloodStock> findByBloodBankIdAndBloodGroup(Long bloodBankId, BloodGroup bloodGroup);

    /** All stock for a specific bank */
    List<BloodStock> findByBloodBankOrderByBloodGroupAsc(BloodBank bloodBank);

    List<BloodStock> findByBloodBankId(Long bloodBankId);

    /**
     * Public blood availability: only from VERIFIED and active banks.
     * Supports filtering by blood group and location.
     * Uses JOIN FETCH to eagerly load BloodBank for view rendering under open-in-view=false.
     */
    @Query(value = """
            SELECT s FROM BloodStock s
            JOIN FETCH s.bloodBank b
            WHERE b.status = 'VERIFIED'
              AND b.active = true
              AND (:bloodGroup IS NULL OR s.bloodGroup = :bloodGroup)
              AND (:state IS NULL OR LOWER(b.state) LIKE LOWER(CONCAT('%', :state, '%')))
              AND (:district IS NULL OR LOWER(b.district) LIKE LOWER(CONCAT('%', :district, '%')))
            ORDER BY b.name ASC, s.bloodGroup ASC
            """,
            countQuery = """
            SELECT COUNT(s) FROM BloodStock s
            JOIN s.bloodBank b
            WHERE b.status = 'VERIFIED'
              AND b.active = true
              AND (:bloodGroup IS NULL OR s.bloodGroup = :bloodGroup)
              AND (:state IS NULL OR LOWER(b.state) LIKE LOWER(CONCAT('%', :state, '%')))
              AND (:district IS NULL OR LOWER(b.district) LIKE LOWER(CONCAT('%', :district, '%')))
            """)
    Page<BloodStock> findPublicAvailability(
            @Param("bloodGroup") BloodGroup bloodGroup,
            @Param("state") String state,
            @Param("district") String district,
            Pageable pageable);

    /** Count total stock records */
    @Query("SELECT COUNT(s) FROM BloodStock s")
    long countAll();

    /** Check if a stock record exists (for demo data dedup) */
    boolean existsByBloodBankAndBloodGroup(BloodBank bloodBank, BloodGroup bloodGroup);
}
