package com.bloodbridge.security;

import com.bloodbridge.entity.AdminUser;
import com.bloodbridge.entity.AppUser;
import com.bloodbridge.repository.AdminUserRepository;
import com.bloodbridge.repository.AppUserRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final AdminUserRepository adminUserRepository;
    private final AppUserRepository appUserRepository;

    public CustomUserDetailsService(AdminUserRepository adminUserRepository,
                                    AppUserRepository appUserRepository) {
        this.adminUserRepository = adminUserRepository;
        this.appUserRepository = appUserRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // First check admin_users
        Optional<AdminUser> admin = adminUserRepository.findByUsername(username);
        if (admin.isPresent()) {
            AdminUser a = admin.get();
            if (Boolean.TRUE.equals(a.getActive())) {
                return new User(
                        a.getUsername(),
                        a.getPasswordHash(),
                        List.of(new SimpleGrantedAuthority("ROLE_ADMIN"))
                );
            }
        }

        // Then check app_users
        Optional<AppUser> appUser = appUserRepository.findByUsername(username);
        if (appUser.isPresent()) {
            AppUser u = appUser.get();
            if (Boolean.TRUE.equals(u.getActive())) {
                String roleAuthority = "ROLE_" + u.getRole().name();
                return new User(
                        u.getUsername(),
                        u.getPasswordHash(),
                        List.of(new SimpleGrantedAuthority(roleAuthority))
                );
            }
        }

        throw new UsernameNotFoundException("Authentication failed.");
    }
}
