package com.bloodbridge.integration;

import com.bloodbridge.dto.DonorRegistrationForm;
import com.bloodbridge.dto.UserRegisterForm;
import com.bloodbridge.entity.AppUser;
import com.bloodbridge.entity.BloodRequest;
import com.bloodbridge.entity.Donor;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.DonorStatus;
import com.bloodbridge.enums.RequestStatus;
import com.bloodbridge.enums.UserRole;
import com.bloodbridge.repository.BloodRequestRepository;
import com.bloodbridge.repository.DonorRepository;
import com.bloodbridge.service.BloodRequestService;
import com.bloodbridge.service.DonorService;
import com.bloodbridge.service.UserService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class UserPortalsServiceTest {

    @Autowired
    private UserService userService;

    @Autowired
    private DonorService donorService;

    @Autowired
    private BloodRequestService bloodRequestService;

    @Autowired
    private DonorRepository donorRepository;

    @Autowired
    private BloodRequestRepository bloodRequestRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Test
    @DisplayName("User can register as DONOR with hashed password")
    void testRegisterDonorUser() {
        UserRegisterForm form = new UserRegisterForm();
        form.setUsername("johndonor");
        form.setPassword("SecretPass123");
        form.setFullName("John Donor");
        form.setEmail("john@example.com");
        form.setPhone("9876543210");

        AppUser user = userService.register(form, UserRole.DONOR);
        assertNotNull(user.getId());
        assertEquals(UserRole.DONOR, user.getRole());
        assertNotEquals("SecretPass123", user.getPasswordHash());
        assertTrue(passwordEncoder.matches("SecretPass123", user.getPasswordHash()));
    }

    @Test
    @DisplayName("User can register as REQUESTER with hashed password")
    void testRegisterRequesterUser() {
        UserRegisterForm form = new UserRegisterForm();
        form.setUsername("maryrequester");
        form.setPassword("RequestPass123");
        form.setFullName("Mary Requester");
        form.setEmail("mary@example.com");

        AppUser user = userService.register(form, UserRole.REQUESTER);
        assertNotNull(user.getId());
        assertEquals(UserRole.REQUESTER, user.getRole());
        assertTrue(passwordEncoder.matches("RequestPass123", user.getPasswordHash()));
    }

    @Test
    @DisplayName("Donor registration starts PENDING and links to user")
    void testDonorRegistrationLinkedToUser() {
        UserRegisterForm userForm = new UserRegisterForm();
        userForm.setUsername("donoruser1");
        userForm.setPassword("Pass1234");
        userForm.setFullName("Donor Person");
        AppUser user = userService.register(userForm, UserRole.DONOR);

        DonorRegistrationForm donorForm = new DonorRegistrationForm();
        donorForm.setFullName("Donor Person");
        donorForm.setBloodGroup(BloodGroup.O_POSITIVE);
        donorForm.setAge(28);
        donorForm.setState("Tamil Nadu");
        donorForm.setDistrict("Chennai");
        donorForm.setCity("Guindy");
        donorForm.setPhone("9876543211");
        donorForm.setConsentDataProcessing(true);
        donorForm.setConsentPublicListing(true);
        donorForm.setInformationAccurateConfirmation(true);

        Long donorId = donorService.registerDonor(donorForm, user.getId());
        Donor donor = donorRepository.findById(donorId).orElseThrow();

        assertEquals(DonorStatus.PENDING, donor.getStatus());
        assertEquals(user.getId(), donor.getUserId());
        assertFalse(donor.isPubliclyEligible(), "Pending donor must not be publicly eligible");

        List<Donor> userDonors = donorService.findByUserId(user.getId());
        assertEquals(1, userDonors.size());
        assertEquals(donorId, userDonors.get(0).getId());
    }

    @Test
    @DisplayName("Blood request linked to requester user with PENDING status")
    void testBloodRequestLinkedToUser() {
        UserRegisterForm userForm = new UserRegisterForm();
        userForm.setUsername("reqUser1");
        userForm.setPassword("Pass1234");
        userForm.setFullName("Requester Person");
        AppUser user = userService.register(userForm, UserRole.REQUESTER);

        com.bloodbridge.dto.BloodRequestForm reqForm = new com.bloodbridge.dto.BloodRequestForm();
        reqForm.setRequesterName("Requester Person");
        reqForm.setBloodGroup(BloodGroup.B_POSITIVE);
        reqForm.setUnitsRequired(2);
        reqForm.setState("Karnataka");
        reqForm.setDistrict("Bangalore");
        reqForm.setCity("Whitefield");
        reqForm.setRequesterPhone("9988776655");

        Long reqId = bloodRequestService.submitRequest(reqForm, user.getId());
        BloodRequest req = bloodRequestRepository.findById(reqId).orElseThrow();

        assertEquals(RequestStatus.PENDING, req.getStatus());
        assertEquals(user.getId(), req.getUserId());

        List<BloodRequest> userRequests = bloodRequestService.findByUserId(user.getId());
        assertEquals(1, userRequests.size());
        assertEquals(reqId, userRequests.get(0).getId());
    }
}
