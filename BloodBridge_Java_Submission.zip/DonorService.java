package com.bloodbridge.service;

import com.bloodbridge.dto.DonorPublicView;
import com.bloodbridge.dto.DonorRegistrationForm;
import com.bloodbridge.entity.Donor;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.DonorStatus;
import com.bloodbridge.exception.BusinessRuleException;
import com.bloodbridge.exception.ResourceNotFoundException;
import com.bloodbridge.repository.DonorRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * Business logic for blood donor management.
 *
 * CRITICAL PRIVACY RULES:
 * - Public methods return DonorPublicView (never Donor entity)
 * - Phone and email are never included in public-facing return types
 * - Visibility rules are enforced at the repository query level AND
 *   validated in service methods for defense-in-depth
 */
@Service
public class DonorService {

    private static final Logger logger = LoggerFactory.getLogger(DonorService.class);
    private static final int DEFAULT_PAGE_SIZE = 12;

    private final DonorRepository donorRepository;
    private final AuditLogService auditLogService;

    public DonorService(DonorRepository donorRepository, AuditLogService auditLogService) {
        this.donorRepository = donorRepository;
        this.auditLogService = auditLogService;
    }

    // ============================================================
    // PUBLIC METHODS
    // ============================================================

    /**
     * Register a new donor. New registrations always start as PENDING.
     * Returns the saved donor's ID (not the full entity).
     */
    @Transactional
    public Long registerDonor(DonorRegistrationForm form) {
        return registerDonor(form, null);
    }

    @Transactional
    public Long registerDonor(DonorRegistrationForm form, Long userId) {
        Donor donor = new Donor();
        donor.setUserId(userId);
        donor.setFullName(form.getFullName().trim());
        donor.setBloodGroup(form.getBloodGroup());
        donor.setAge(form.getAge());
        donor.setState(form.getState().trim());
        donor.setDistrict(form.getDistrict().trim());
        donor.setCity(form.getCity().trim());
        donor.setPhone(form.getPhone().trim());
        donor.setEmail(form.getEmail() != null ? form.getEmail().trim() : null);
        donor.setAvailable(Boolean.TRUE.equals(form.getAvailable()));
        donor.setConsentDataProcessing(Boolean.TRUE.equals(form.getConsentDataProcessing()));
        donor.setConsentPublicListing(Boolean.TRUE.equals(form.getConsentPublicListing()));
        donor.setInformationAccurateConfirmation(Boolean.TRUE.equals(form.getInformationAccurateConfirmation()));
        // Always start as PENDING regardless of input
        donor.setStatus(DonorStatus.PENDING);
        donor.setActive(true);

        Donor saved = donorRepository.save(donor);
        logger.info("New donor registration: ID={}, bloodGroup={}, city={}",
                saved.getId(), saved.getBloodGroup(), saved.getCity());
        return saved.getId();
    }

    /**
     * Search for publicly eligible donors with optional filters.
     * Returns only safe public view data — never the full entity.
     */
    @Transactional(readOnly = true)
    public Page<DonorPublicView> searchPublicDonors(BloodGroup bloodGroup,
                                                     String state, String district, String city,
                                                     int page) {
        Pageable pageable = PageRequest.of(Math.max(0, page), DEFAULT_PAGE_SIZE);

        // Normalize empty strings to null so the JPQL query skips those filters
        BloodGroup bg = bloodGroup;
        String st = normalizeFilter(state);
        String dist = normalizeFilter(district);
        String ct = normalizeFilter(city);

        Page<Donor> donors = donorRepository.findPubliclyEligible(bg, st, dist, ct, pageable);

        // Map to safe public view — NEVER include phone or email
        return donors.map(d -> new DonorPublicView(
                d.getId(),
                d.getDisplayName(),   // first name + last initial only
                d.getBloodGroup(),
                d.getCity(),
                d.getDistrict(),
                d.getState(),
                d.getAvailable(),
                d.getUpdatedAt()
        ));
    }

    @Transactional(readOnly = true)
    public List<Donor> findByUserId(Long userId) {
        return donorRepository.findByUserIdOrderByRegisteredAtDesc(userId);
    }

    // ============================================================
    // ADMIN METHODS
    // ============================================================

    /**
     * Retrieve full donor entity for admin review (includes private fields).
     * ONLY call from admin-protected controllers.
     */
    @Transactional(readOnly = true)
    public Donor getForAdmin(Long id) {
        return donorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Donor", id));
    }

    /**
     * List all donors for admin with optional status filter.
     */
    @Transactional(readOnly = true)
    public Page<Donor> findAllForAdmin(DonorStatus status, int page) {
        Pageable pageable = PageRequest.of(Math.max(0, page), 20);
        return donorRepository.findAllByStatusFilter(status, pageable);
    }

    /**
     * Verify a donor (approve their registration).
     * Does NOT automatically make them public — they also need consentPublicListing = true.
     */
    @Transactional
    public void verifyDonor(Long id, String adminUsername, String notes) {
        Donor donor = getDonorOrThrow(id);

        if (donor.getStatus() == DonorStatus.VERIFIED) {
            throw new BusinessRuleException("Donor is already verified.");
        }

        donor.setStatus(DonorStatus.VERIFIED);
        if (StringUtils.hasText(notes)) {
            donor.setAdminNotes(notes);
        }
        donorRepository.save(donor);

        auditLogService.log(adminUsername, "DONOR_VERIFIED", "DONOR", id,
                "Donor ID=" + id + " (" + donor.getDisplayName() + ") verified. " +
                        "Public listing: " + (donor.isPubliclyEligible() ? "YES" : "NO (conditions not met)"));
    }

    /**
     * Reject a donor registration.
     */
    @Transactional
    public void rejectDonor(Long id, String adminUsername, String notes) {
        Donor donor = getDonorOrThrow(id);

        if (donor.getStatus() == DonorStatus.REJECTED) {
            throw new BusinessRuleException("Donor is already rejected.");
        }

        donor.setStatus(DonorStatus.REJECTED);
        if (StringUtils.hasText(notes)) {
            donor.setAdminNotes(notes);
        }
        donorRepository.save(donor);

        auditLogService.log(adminUsername, "DONOR_REJECTED", "DONOR", id,
                "Donor ID=" + id + " rejected.");
    }

    /**
     * Deactivate a donor listing (e.g., on removal request).
     */
    @Transactional
    public void deactivateDonor(Long id, String adminUsername, String notes) {
        Donor donor = getDonorOrThrow(id);
        donor.setStatus(DonorStatus.INACTIVE);
        donor.setActive(false);
        if (StringUtils.hasText(notes)) {
            donor.setAdminNotes(notes);
        }
        donorRepository.save(donor);

        auditLogService.log(adminUsername, "DONOR_DEACTIVATED", "DONOR", id,
                "Donor ID=" + id + " deactivated/removed from public listing.");
    }

    /**
     * Update donor availability status.
     */
    @Transactional
    public void updateAvailability(Long id, boolean available, String adminUsername) {
        Donor donor = getDonorOrThrow(id);
        donor.setAvailable(available);
        donorRepository.save(donor);

        auditLogService.log(adminUsername, "DONOR_AVAILABILITY_UPDATED", "DONOR", id,
                "Donor ID=" + id + " availability set to: " + available);
    }

    // ============================================================
    // DASHBOARD STATISTICS
    // ============================================================

    public long countTotal() { return donorRepository.count(); }
    public long countPending() { return donorRepository.countByStatus(DonorStatus.PENDING); }
    public long countPubliclyEligible() { return donorRepository.countPubliclyEligible(); }

    // ============================================================
    // HELPERS
    // ============================================================

    private Donor getDonorOrThrow(Long id) {
        return donorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Donor", id));
    }

    private String normalizeFilter(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim();
    }
}
