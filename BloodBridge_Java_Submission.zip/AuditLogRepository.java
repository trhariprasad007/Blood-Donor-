package com.bloodbridge.repository;

import com.bloodbridge.entity.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    /** Retrieve all logs ordered by most recent first */
    Page<AuditLog> findAllByOrderByPerformedAtDesc(Pageable pageable);

    /** Logs for a specific administrator */
    Page<AuditLog> findByAdminUsernameOrderByPerformedAtDesc(String adminUsername, Pageable pageable);

    /** Logs for a specific entity (e.g., all changes to a specific donor) */
    Page<AuditLog> findByEntityTypeAndEntityIdOrderByPerformedAtDesc(
            String entityType, Long entityId, Pageable pageable);
}
