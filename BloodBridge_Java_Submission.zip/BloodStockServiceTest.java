package com.bloodbridge.service;

import com.bloodbridge.dto.BloodStockForm;
import com.bloodbridge.entity.BloodBank;
import com.bloodbridge.entity.BloodStock;
import com.bloodbridge.enums.BankStatus;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.exception.BusinessRuleException;
import com.bloodbridge.repository.BloodBankRepository;
import com.bloodbridge.repository.BloodStockRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class BloodStockServiceTest {

    @Autowired
    private BloodStockService bloodStockService;

    @Autowired
    private BloodBankRepository bloodBankRepository;

    @Autowired
    private BloodStockRepository bloodStockRepository;

    private BloodBank bank;

    @BeforeEach
    void setup() {
        bank = new BloodBank();
        bank.setName("Central City Blood Bank");
        bank.setAddress("45 Healthcare Blvd");
        bank.setState("Tamil Nadu");
        bank.setDistrict("Chennai");
        bank.setCity("Guindy");
        bank.setStatus(BankStatus.VERIFIED);
        bank.setActive(true);
        bank = bloodBankRepository.save(bank);
    }

    @Test
    @DisplayName("Valid stock creation persists unit count")
    void testAddStockSuccess() {
        BloodStockForm form = new BloodStockForm();
        form.setBloodBankId(bank.getId());
        form.setBloodGroup(BloodGroup.B_POSITIVE);
        form.setUnits(15);
        form.setAdminRemarks("Initial count");

        BloodStock stock = bloodStockService.addStockRecord(form, "admin");

        assertNotNull(stock.getId());
        assertEquals(15, stock.getUnits());
        assertEquals(BloodGroup.B_POSITIVE, stock.getBloodGroup());
    }

    @Test
    @DisplayName("Negative stock creation is rejected")
    void testNegativeUnitsRejected() {
        BloodStockForm form = new BloodStockForm();
        form.setBloodBankId(bank.getId());
        form.setBloodGroup(BloodGroup.O_NEGATIVE);
        form.setUnits(-5);

        assertThrows(BusinessRuleException.class, () -> bloodStockService.addStockRecord(form, "admin"));
    }

    @Test
    @DisplayName("Duplicate blood group record for same bank is rejected")
    void testDuplicateGroupRejected() {
        BloodStockForm form1 = new BloodStockForm();
        form1.setBloodBankId(bank.getId());
        form1.setBloodGroup(BloodGroup.A_POSITIVE);
        form1.setUnits(10);
        bloodStockService.addStockRecord(form1, "admin");

        BloodStockForm form2 = new BloodStockForm();
        form2.setBloodBankId(bank.getId());
        form2.setBloodGroup(BloodGroup.A_POSITIVE);
        form2.setUnits(5);

        assertThrows(BusinessRuleException.class, () -> bloodStockService.addStockRecord(form2, "admin"));
    }

    @Test
    @DisplayName("Stock update changes unit count and refreshes timestamp")
    void testUpdateStockSuccess() {
        BloodStockForm form = new BloodStockForm();
        form.setBloodBankId(bank.getId());
        form.setBloodGroup(BloodGroup.AB_POSITIVE);
        form.setUnits(8);
        BloodStock stock = bloodStockService.addStockRecord(form, "admin");

        bloodStockService.updateStockRecord(stock.getId(), 12, "Re-verified count", "admin");

        BloodStock updated = bloodStockService.getById(stock.getId());
        assertEquals(12, updated.getUnits());
    }
}
