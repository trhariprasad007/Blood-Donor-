package com.bloodbridge.controller;

import com.bloodbridge.dto.DonorRegistrationForm;
import com.bloodbridge.dto.UserRegisterForm;
import com.bloodbridge.entity.AppUser;
import com.bloodbridge.entity.Donor;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.UserRole;
import com.bloodbridge.service.DonorService;
import com.bloodbridge.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/donor")
public class DonorPortalController {

    private final UserService userService;
    private final DonorService donorService;

    public DonorPortalController(UserService userService, DonorService donorService) {
        this.userService = userService;
        this.donorService = donorService;
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("pageTitle", "Donor Login — BloodBridge");
        return "donor/login";
    }

    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("userForm", new UserRegisterForm());
        model.addAttribute("pageTitle", "Donor Account Signup — BloodBridge");
        return "donor/register";
    }

    @PostMapping("/register")
    public String processRegister(@Valid @ModelAttribute("userForm") UserRegisterForm form,
                                  BindingResult bindingResult,
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("pageTitle", "Donor Account Signup — BloodBridge");
            return "donor/register";
        }
        try {
            userService.register(form, UserRole.DONOR);
            redirectAttributes.addFlashAttribute("successMessage", "Account created successfully! Please sign in.");
            return "redirect:/donor/login";
        } catch (Exception ex) {
            model.addAttribute("errorMessage", ex.getMessage());
            model.addAttribute("pageTitle", "Donor Account Signup — BloodBridge");
            return "donor/register";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        AppUser user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalStateException("User not found: " + userDetails.getUsername()));

        List<Donor> registrations = donorService.findByUserId(user.getId());
        model.addAttribute("user", user);
        model.addAttribute("registrations", registrations);
        model.addAttribute("pageTitle", "Donor Portal Dashboard — BloodBridge");
        return "donor/dashboard";
    }

    @GetMapping("/submit-registration")
    public String showSubmissionForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        AppUser user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalStateException("User not found: " + userDetails.getUsername()));

        DonorRegistrationForm form = new DonorRegistrationForm();
        form.setFullName(user.getFullName());
        form.setEmail(user.getEmail());
        form.setPhone(user.getPhone() != null ? user.getPhone() : "");

        model.addAttribute("registrationForm", form);
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("pageTitle", "Submit Donor Profile — BloodBridge");
        return "donor/submit-registration";
    }

    @PostMapping("/submit-registration")
    public String submitRegistration(@AuthenticationPrincipal UserDetails userDetails,
                                     @Valid @ModelAttribute("registrationForm") DonorRegistrationForm form,
                                     BindingResult bindingResult,
                                     Model model,
                                     RedirectAttributes redirectAttributes) {
        AppUser user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalStateException("User not found: " + userDetails.getUsername()));

        if (bindingResult.hasErrors()) {
            model.addAttribute("bloodGroups", BloodGroup.values());
            model.addAttribute("pageTitle", "Submit Donor Profile — BloodBridge");
            return "donor/submit-registration";
        }

        donorService.registerDonor(form, user.getId());
        redirectAttributes.addFlashAttribute("successMessage",
                "Donor registration submitted successfully! It is now pending admin review.");
        return "redirect:/donor/dashboard";
    }
}
