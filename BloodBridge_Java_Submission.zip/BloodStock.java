package com.bloodbridge.entity;

import com.bloodbridge.enums.BloodGroup;
import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.time.LocalDateTime;

/**
 * Blood stock record for a specific blood group at a specific blood bank.
 * Enforces a unique constraint: one record per (blood_bank, blood_group).
 *
 * IMPORTANT:
 * - units must always be >= 0 (enforced at DB and service level)
 * - Stock is manually updated by administrators
 * - This does NOT represent live hospital inventory
 * - updatedAt must be refreshed on every successful unit update
 */
@Entity
@Table(name = "blood_stock",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_bank_blood_group",
                        columnNames = {"blood_bank_id", "blood_group"})
        },
        indexes = {
                @Index(name = "idx_stock_blood_group", columnList = "blood_group"),
                @Index(name = "idx_stock_bank", columnList = "blood_bank_id")
        })
public class BloodStock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "blood_bank_id", nullable = false)
    private BloodBank bloodBank;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(name = "blood_group", nullable = false, length = 20)
    private BloodGroup bloodGroup;

    /**
     * Number of recorded units. Must be >= 0.
     * Null means "not yet reported" (different from 0 units).
     */
    @Column(name = "units", nullable = false)
    private Integer units = 0;

    /** Administrative remarks - never shown publicly */
    @Column(name = "admin_remarks", length = 500)
    private String adminRemarks;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /** Updated every time an administrator changes the unit count */
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    /** Optimistic locking to prevent conflicting concurrent updates */
    @Version
    @Column(name = "version")
    private Long version;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (units == null || units < 0) units = 0;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // ========== Getters and Setters ==========

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public BloodBank getBloodBank() { return bloodBank; }
    public void setBloodBank(BloodBank bloodBank) { this.bloodBank = bloodBank; }

    public BloodGroup getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(BloodGroup bloodGroup) { this.bloodGroup = bloodGroup; }

    public Integer getUnits() { return units; }
    public void setUnits(Integer units) {
        if (units != null && units < 0) {
            throw new IllegalArgumentException("Blood stock units cannot be negative.");
        }
        this.units = units;
    }

    public String getAdminRemarks() { return adminRemarks; }
    public void setAdminRemarks(String adminRemarks) { this.adminRemarks = adminRemarks; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public Long getVersion() { return version; }
    public void setVersion(Long version) { this.version = version; }
}
