package com.bloodbridge.service;

import com.bloodbridge.entity.BloodBank;
import com.bloodbridge.enums.BankStatus;
import com.bloodbridge.exception.BusinessRuleException;
import com.bloodbridge.exception.ResourceNotFoundException;
import com.bloodbridge.repository.BloodBankRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/**
 * Business logic for blood bank directory management.
 */
@Service
public class BloodBankService {

    private static final Logger logger = LoggerFactory.getLogger(BloodBankService.class);
    private static final int DEFAULT_PAGE_SIZE = 12;

    private final BloodBankRepository bloodBankRepository;
    private final AuditLogService auditLogService;

    public BloodBankService(BloodBankRepository bloodBankRepository, AuditLogService auditLogService) {
        this.bloodBankRepository = bloodBankRepository;
        this.auditLogService = auditLogService;
    }

    // ============================================================
    // PUBLIC METHODS
    // ============================================================

    /**
     * Search for publicly visible blood banks (VERIFIED + active).
     */
    @Transactional(readOnly = true)
    public Page<BloodBank> searchPublic(String name, String state, String district, String city, int page) {
        Pageable pageable = PageRequest.of(Math.max(0, page), DEFAULT_PAGE_SIZE);
        return bloodBankRepository.findPubliclyVisible(
                normalizeFilter(name),
                normalizeFilter(state),
                normalizeFilter(district),
                normalizeFilter(city),
                pageable);
    }

    /**
     * Get a single blood bank for the public page.
     * Only returns if it is publicly visible.
     */
    @Transactional(readOnly = true)
    public BloodBank getPublicBank(Long id) {
        BloodBank bank = bloodBankRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Blood bank", id));

        if (!bank.isPubliclyVisible()) {
            throw new ResourceNotFoundException("Blood bank", id);
        }
        return bank;
    }

    // ============================================================
    // ADMIN METHODS
    // ============================================================

    /**
     * Get a blood bank for admin review (regardless of status).
     */
    @Transactional(readOnly = true)
    public BloodBank getForAdmin(Long id) {
        return bloodBankRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Blood bank", id));
    }

    /**
     * List all blood banks for admin, optionally filtered by status.
     */
    @Transactional(readOnly = true)
    public Page<BloodBank> findAllForAdmin(BankStatus status, int page) {
        Pageable pageable = PageRequest.of(Math.max(0, page), 20);
        return bloodBankRepository.findAllByStatusFilter(status, pageable);
    }

    /**
     * Create a new blood bank record (always starts as PENDING).
     */
    @Transactional
    public BloodBank createBank(BloodBank bank, String adminUsername) {
        bank.setStatus(BankStatus.PENDING);
        BloodBank saved = bloodBankRepository.save(bank);
        auditLogService.log(adminUsername, "BANK_CREATED", "BLOOD_BANK", saved.getId(),
                "Blood bank '" + saved.getName() + "' created.");
        return saved;
    }

    /**
     * Update blood bank basic details.
     */
    @Transactional
    public void updateBank(Long id, BloodBank updates, String adminUsername) {
        BloodBank bank = getForAdmin(id);
        bank.setName(updates.getName());
        bank.setAddress(updates.getAddress());
        bank.setState(updates.getState());
        bank.setDistrict(updates.getDistrict());
        bank.setCity(updates.getCity());
        bank.setContactPhone(updates.getContactPhone());
        bank.setContactEmail(updates.getContactEmail());
        bank.setWebsiteUrl(updates.getWebsiteUrl());
        if (StringUtils.hasText(updates.getAdminNotes())) {
            bank.setAdminNotes(updates.getAdminNotes());
        }
        bloodBankRepository.save(bank);
        auditLogService.log(adminUsername, "BANK_UPDATED", "BLOOD_BANK", id,
                "Blood bank ID=" + id + " details updated.");
    }

    /**
     * Verify a blood bank.
     */
    @Transactional
    public void verifyBank(Long id, String adminUsername, String notes) {
        BloodBank bank = getForAdmin(id);
        if (bank.getStatus() == BankStatus.VERIFIED) {
            throw new BusinessRuleException("Blood bank is already verified.");
        }
        bank.setStatus(BankStatus.VERIFIED);
        if (StringUtils.hasText(notes)) bank.setAdminNotes(notes);
        bloodBankRepository.save(bank);
        auditLogService.log(adminUsername, "BANK_VERIFIED", "BLOOD_BANK", id,
                "Blood bank '" + bank.getName() + "' verified and activated.");
    }

    /**
     * Reject a blood bank.
     */
    @Transactional
    public void rejectBank(Long id, String adminUsername, String notes) {
        BloodBank bank = getForAdmin(id);
        bank.setStatus(BankStatus.REJECTED);
        if (StringUtils.hasText(notes)) bank.setAdminNotes(notes);
        bloodBankRepository.save(bank);
        auditLogService.log(adminUsername, "BANK_REJECTED", "BLOOD_BANK", id,
                "Blood bank ID=" + id + " rejected.");
    }

    /**
     * Deactivate a blood bank.
     */
    @Transactional
    public void deactivateBank(Long id, String adminUsername, String notes) {
        BloodBank bank = getForAdmin(id);
        bank.setStatus(BankStatus.INACTIVE);
        bank.setActive(false);
        if (StringUtils.hasText(notes)) bank.setAdminNotes(notes);
        bloodBankRepository.save(bank);
        auditLogService.log(adminUsername, "BANK_DEACTIVATED", "BLOOD_BANK", id,
                "Blood bank '" + bank.getName() + "' deactivated.");
    }

    // ============================================================
    // DASHBOARD STATISTICS
    // ============================================================

    public long countTotal() { return bloodBankRepository.count(); }
    public long countPending() { return bloodBankRepository.countByStatus(BankStatus.PENDING); }
    public long countVerified() { return bloodBankRepository.countVerifiedActive(); }

    // ============================================================
    // HELPERS
    // ============================================================

    private String normalizeFilter(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim();
    }
}
