package com.bloodbridge.repository;

import com.bloodbridge.entity.Donor;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.DonorStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DonorRepository extends JpaRepository<Donor, Long> {

    /**
     * Find publicly eligible donors with optional filters.
     * A donor is publicly eligible when:
     * status = VERIFIED AND consentPublicListing = true AND available = true AND active = true
     *
     * Filters are applied only when non-null/non-blank.
     * Location matching is case-insensitive.
     */
    @Query("""
            SELECT d FROM Donor d
            WHERE d.status = 'VERIFIED'
              AND d.consentPublicListing = true
              AND d.available = true
              AND d.active = true
              AND (:bloodGroup IS NULL OR d.bloodGroup = :bloodGroup)
              AND (:state IS NULL OR LOWER(d.state) LIKE LOWER(CONCAT('%', :state, '%')))
              AND (:district IS NULL OR LOWER(d.district) LIKE LOWER(CONCAT('%', :district, '%')))
              AND (:city IS NULL OR LOWER(d.city) LIKE LOWER(CONCAT('%', :city, '%')))
            ORDER BY d.updatedAt DESC
            """)
    Page<Donor> findPubliclyEligible(
            @Param("bloodGroup") BloodGroup bloodGroup,
            @Param("state") String state,
            @Param("district") String district,
            @Param("city") String city,
            Pageable pageable);

    /** Count donors by status for admin dashboard */
    long countByStatus(DonorStatus status);

    /** Count publicly eligible donors */
    @Query("""
            SELECT COUNT(d) FROM Donor d
            WHERE d.status = 'VERIFIED'
              AND d.consentPublicListing = true
              AND d.available = true
              AND d.active = true
            """)
    long countPubliclyEligible();

    /** Admin: find all donors with optional status filter */
    @Query("""
            SELECT d FROM Donor d
            WHERE (:status IS NULL OR d.status = :status)
            ORDER BY d.registeredAt DESC
            """)
    Page<Donor> findAllByStatusFilter(@Param("status") DonorStatus status, Pageable pageable);

    /** Check if demo data already exists (by a known demo name) */
    boolean existsByFullName(String fullName);

    /** Find donors by blood group for admin use */
    List<Donor> findByBloodGroup(BloodGroup bloodGroup);

    /** Find donor registrations linked to a specific user account */
    List<Donor> findByUserIdOrderByRegisteredAtDesc(Long userId);
}
