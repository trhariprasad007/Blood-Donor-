package com.bloodbridge.service;

import com.bloodbridge.dto.BloodRequestForm;
import com.bloodbridge.entity.BloodRequest;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.RequestStatus;
import com.bloodbridge.exception.BusinessRuleException;
import com.bloodbridge.repository.BloodRequestRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class BloodRequestServiceTest {

    @Autowired
    private BloodRequestService bloodRequestService;

    @Autowired
    private BloodRequestRepository bloodRequestRepository;

    private BloodRequestForm createValidForm() {
        BloodRequestForm form = new BloodRequestForm();
        form.setRequesterName("Anitha Raj");
        form.setBloodGroup(BloodGroup.O_NEGATIVE);
        form.setUnitsRequired(2);
        form.setState("Tamil Nadu");
        form.setDistrict("Chennai");
        form.setCity("T. Nagar");
        form.setHospitalName("City Care Hospital");
        form.setRequesterPhone("9876543210");
        return form;
    }

    @Test
    @DisplayName("Blood request submission starts in PENDING status")
    void testRequestStartsPending() {
        BloodRequestForm form = createValidForm();
        Long id = bloodRequestService.submitRequest(form);

        assertNotNull(id);
        BloodRequest req = bloodRequestRepository.findById(id).orElseThrow();
        assertEquals(RequestStatus.PENDING, req.getStatus());
        assertEquals("Anitha Raj", req.getRequesterName());
        assertEquals(2, req.getUnitsRequired());
    }

    @Test
    @DisplayName("Valid status transition from PENDING to UNDER_REVIEW succeeds")
    void testValidStatusTransition() {
        BloodRequestForm form = createValidForm();
        Long id = bloodRequestService.submitRequest(form);

        bloodRequestService.updateStatus(id, RequestStatus.UNDER_REVIEW, "Doctor verification in progress", "admin");

        BloodRequest req = bloodRequestRepository.findById(id).orElseThrow();
        assertEquals(RequestStatus.UNDER_REVIEW, req.getStatus());
    }

    @Test
    @DisplayName("Invalid status transition directly from PENDING to COMPLETED is rejected")
    void testInvalidStatusTransitionRejected() {
        BloodRequestForm form = createValidForm();
        Long id = bloodRequestService.submitRequest(form);

        assertThrows(BusinessRuleException.class, () ->
                bloodRequestService.updateStatus(id, RequestStatus.COMPLETED, "Skipping review", "admin"));
    }
}
