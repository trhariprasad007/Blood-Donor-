package com.bloodbridge.controller;

import com.bloodbridge.dto.BloodStockForm;
import com.bloodbridge.entity.*;
import com.bloodbridge.enums.*;
import com.bloodbridge.repository.BloodBankRepository;
import com.bloodbridge.service.*;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Arrays;

/**
 * Administrator dashboard and management controller.
 * ALL routes require ROLE_ADMIN (enforced by SecurityConfig).
 * Private data (phone, email) is accessible here for admin review only.
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    private final DonorService donorService;
    private final BloodBankService bloodBankService;
    private final BloodStockService bloodStockService;
    private final BloodRequestService bloodRequestService;
    private final AuditLogService auditLogService;
    private final BloodBankRepository bloodBankRepository;

    public AdminController(DonorService donorService,
                           BloodBankService bloodBankService,
                           BloodStockService bloodStockService,
                           BloodRequestService bloodRequestService,
                           AuditLogService auditLogService,
                           BloodBankRepository bloodBankRepository) {
        this.donorService = donorService;
        this.bloodBankService = bloodBankService;
        this.bloodStockService = bloodStockService;
        this.bloodRequestService = bloodRequestService;
        this.auditLogService = auditLogService;
        this.bloodBankRepository = bloodBankRepository;
    }

    // ============================================================
    // LOGIN
    // ============================================================

    @GetMapping("/login")
    public String loginPage() {
        return "admin/login";
    }

    // ============================================================
    // DASHBOARD
    // ============================================================

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("totalDonors", donorService.countTotal());
        model.addAttribute("pendingDonors", donorService.countPending());
        model.addAttribute("publicDonors", donorService.countPubliclyEligible());
        model.addAttribute("totalBanks", bloodBankService.countTotal());
        model.addAttribute("pendingBanks", bloodBankService.countPending());
        model.addAttribute("totalStock", bloodStockService.countTotal());
        model.addAttribute("pendingRequests", bloodRequestService.countPending());
        model.addAttribute("activeRequests", bloodRequestService.countActive());
        model.addAttribute("pageTitle", "Admin Dashboard — BloodBridge");
        return "admin/dashboard";
    }

    // ============================================================
    // DONOR MANAGEMENT
    // ============================================================

    @GetMapping("/donors")
    public String listDonors(
            @RequestParam(required = false) DonorStatus status,
            @RequestParam(defaultValue = "0") int page,
            Model model) {

        Page<Donor> donors = donorService.findAllForAdmin(status, page);
        model.addAttribute("donors", donors);
        model.addAttribute("statuses", DonorStatus.values());
        model.addAttribute("selectedStatus", status);
        model.addAttribute("currentPage", page);
        model.addAttribute("pageTitle", "Donor Management — BloodBridge Admin");
        return "admin/donors/list";
    }

    @GetMapping("/donors/{id}")
    public String viewDonor(@PathVariable Long id, Model model) {
        Donor donor = donorService.getForAdmin(id);
        model.addAttribute("donor", donor);
        model.addAttribute("pageTitle", "Donor Details — BloodBridge Admin");
        return "admin/donors/detail";
    }

    @PostMapping("/donors/{id}/verify")
    public String verifyDonor(@PathVariable Long id,
                               @RequestParam(required = false) String notes,
                               @AuthenticationPrincipal UserDetails admin,
                               RedirectAttributes redirectAttributes) {
        donorService.verifyDonor(id, admin.getUsername(), notes);
        redirectAttributes.addFlashAttribute("successMessage", "Donor verified successfully.");
        return "redirect:/admin/donors/" + id;
    }

    @PostMapping("/donors/{id}/reject")
    public String rejectDonor(@PathVariable Long id,
                               @RequestParam(required = false) String notes,
                               @AuthenticationPrincipal UserDetails admin,
                               RedirectAttributes redirectAttributes) {
        donorService.rejectDonor(id, admin.getUsername(), notes);
        redirectAttributes.addFlashAttribute("successMessage", "Donor rejected.");
        return "redirect:/admin/donors/" + id;
    }

    @PostMapping("/donors/{id}/deactivate")
    public String deactivateDonor(@PathVariable Long id,
                                   @RequestParam(required = false) String notes,
                                   @AuthenticationPrincipal UserDetails admin,
                                   RedirectAttributes redirectAttributes) {
        donorService.deactivateDonor(id, admin.getUsername(), notes);
        redirectAttributes.addFlashAttribute("successMessage", "Donor deactivated.");
        return "redirect:/admin/donors/" + id;
    }

    @PostMapping("/donors/{id}/availability")
    public String updateAvailability(@PathVariable Long id,
                                      @RequestParam boolean available,
                                      @AuthenticationPrincipal UserDetails admin,
                                      RedirectAttributes redirectAttributes) {
        donorService.updateAvailability(id, available, admin.getUsername());
        redirectAttributes.addFlashAttribute("successMessage",
                "Availability updated to: " + (available ? "Available" : "Unavailable"));
        return "redirect:/admin/donors/" + id;
    }

    // ============================================================
    // BLOOD BANK MANAGEMENT
    // ============================================================

    @GetMapping("/blood-banks")
    public String listBanks(
            @RequestParam(required = false) BankStatus status,
            @RequestParam(defaultValue = "0") int page,
            Model model) {

        Page<BloodBank> banks = bloodBankService.findAllForAdmin(status, page);
        model.addAttribute("banks", banks);
        model.addAttribute("statuses", BankStatus.values());
        model.addAttribute("selectedStatus", status);
        model.addAttribute("currentPage", page);
        model.addAttribute("pageTitle", "Blood Bank Management — BloodBridge Admin");
        return "admin/blood-banks/list";
    }

    @GetMapping("/blood-banks/{id}")
    public String viewBank(@PathVariable Long id, Model model) {
        BloodBank bank = bloodBankService.getForAdmin(id);
        model.addAttribute("bank", bank);
        model.addAttribute("stock", bloodStockService.getStockForBank(id));
        model.addAttribute("pageTitle", "Blood Bank Details — BloodBridge Admin");
        return "admin/blood-banks/detail";
    }

    @GetMapping("/blood-banks/new")
    public String newBankForm(Model model) {
        model.addAttribute("bank", new BloodBank());
        model.addAttribute("pageTitle", "Add Blood Bank — BloodBridge Admin");
        return "admin/blood-banks/form";
    }

    @PostMapping("/blood-banks/new")
    public String createBank(@ModelAttribute BloodBank bank,
                              @AuthenticationPrincipal UserDetails admin,
                              RedirectAttributes redirectAttributes) {
        BloodBank saved = bloodBankService.createBank(bank, admin.getUsername());
        redirectAttributes.addFlashAttribute("successMessage", "Blood bank added successfully.");
        return "redirect:/admin/blood-banks/" + saved.getId();
    }

    @PostMapping("/blood-banks/{id}/verify")
    public String verifyBank(@PathVariable Long id,
                              @RequestParam(required = false) String notes,
                              @AuthenticationPrincipal UserDetails admin,
                              RedirectAttributes redirectAttributes) {
        bloodBankService.verifyBank(id, admin.getUsername(), notes);
        redirectAttributes.addFlashAttribute("successMessage", "Blood bank verified.");
        return "redirect:/admin/blood-banks/" + id;
    }

    @PostMapping("/blood-banks/{id}/reject")
    public String rejectBank(@PathVariable Long id,
                              @RequestParam(required = false) String notes,
                              @AuthenticationPrincipal UserDetails admin,
                              RedirectAttributes redirectAttributes) {
        bloodBankService.rejectBank(id, admin.getUsername(), notes);
        redirectAttributes.addFlashAttribute("successMessage", "Blood bank rejected.");
        return "redirect:/admin/blood-banks/" + id;
    }

    @PostMapping("/blood-banks/{id}/deactivate")
    public String deactivateBank(@PathVariable Long id,
                                  @RequestParam(required = false) String notes,
                                  @AuthenticationPrincipal UserDetails admin,
                                  RedirectAttributes redirectAttributes) {
        bloodBankService.deactivateBank(id, admin.getUsername(), notes);
        redirectAttributes.addFlashAttribute("successMessage", "Blood bank deactivated.");
        return "redirect:/admin/blood-banks/" + id;
    }

    // ============================================================
    // BLOOD STOCK MANAGEMENT
    // ============================================================

    @GetMapping("/stock")
    public String stockList(@RequestParam(defaultValue = "0") int page, Model model) {
        // Show all banks for stock management
        model.addAttribute("banks", bloodBankRepository.findAll());
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("stockForm", new BloodStockForm());
        model.addAttribute("pageTitle", "Blood Stock Management — BloodBridge Admin");
        return "admin/stock/list";
    }

    @GetMapping("/stock/bank/{bankId}")
    public String bankStock(@PathVariable Long bankId, Model model) {
        BloodBank bank = bloodBankService.getForAdmin(bankId);
        model.addAttribute("bank", bank);
        model.addAttribute("stock", bloodStockService.getStockForBank(bankId));
        model.addAttribute("bloodGroups", BloodGroup.values());
        BloodStockForm form = new BloodStockForm();
        form.setBloodBankId(bankId);
        model.addAttribute("stockForm", form);
        model.addAttribute("pageTitle", "Stock: " + bank.getName() + " — BloodBridge Admin");
        return "admin/stock/bank-stock";
    }

    @PostMapping("/stock/add")
    public String addStock(@Valid @ModelAttribute("stockForm") BloodStockForm form,
                            BindingResult bindingResult,
                            @AuthenticationPrincipal UserDetails admin,
                            RedirectAttributes redirectAttributes,
                            Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("banks", bloodBankRepository.findAll());
            model.addAttribute("bloodGroups", BloodGroup.values());
            model.addAttribute("pageTitle", "Blood Stock Management — BloodBridge Admin");
            return "admin/stock/list";
        }

        bloodStockService.addStockRecord(form, admin.getUsername());
        redirectAttributes.addFlashAttribute("successMessage",
                "Stock record added for " + form.getBloodGroup().getDisplayName() + ".");

        if (form.getBloodBankId() != null) {
            return "redirect:/admin/stock/bank/" + form.getBloodBankId();
        }
        return "redirect:/admin/stock";
    }

    @GetMapping("/stock/{id}/edit")
    public String editStockForm(@PathVariable Long id, Model model) {
        BloodStock stock = bloodStockService.getById(id);
        model.addAttribute("stock", stock);
        model.addAttribute("pageTitle", "Edit Stock — BloodBridge Admin");
        return "admin/stock/edit";
    }

    @PostMapping("/stock/{id}/update")
    public String updateStock(@PathVariable Long id,
                               @RequestParam int units,
                               @RequestParam(required = false) String adminRemarks,
                               @AuthenticationPrincipal UserDetails admin,
                               RedirectAttributes redirectAttributes) {
        bloodStockService.updateStockRecord(id, units, adminRemarks, admin.getUsername());
        BloodStock stock = bloodStockService.getById(id);
        redirectAttributes.addFlashAttribute("successMessage", "Stock updated successfully.");
        return "redirect:/admin/stock/bank/" + stock.getBloodBank().getId();
    }

    // ============================================================
    // BLOOD REQUEST MANAGEMENT
    // ============================================================

    @GetMapping("/requests")
    public String listRequests(
            @RequestParam(required = false) RequestStatus status,
            @RequestParam(required = false) BloodGroup bloodGroup,
            @RequestParam(defaultValue = "0") int page,
            Model model) {

        Page<BloodRequest> requests = bloodRequestService.findAllForAdmin(status, bloodGroup, page);
        model.addAttribute("requests", requests);
        model.addAttribute("statuses", RequestStatus.values());
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("selectedStatus", status);
        model.addAttribute("selectedBloodGroup", bloodGroup);
        model.addAttribute("currentPage", page);
        model.addAttribute("pageTitle", "Request Management — BloodBridge Admin");
        return "admin/requests/list";
    }

    @GetMapping("/requests/{id}")
    public String viewRequest(@PathVariable Long id, Model model) {
        BloodRequest request = bloodRequestService.getForAdmin(id);
        model.addAttribute("request", request);
        model.addAttribute("validTransitions",
                Arrays.stream(RequestStatus.values())
                        .filter(s -> request.getStatus().canTransitionTo(s))
                        .toList());
        model.addAttribute("pageTitle", "Request Details — BloodBridge Admin");
        return "admin/requests/detail";
    }

    @PostMapping("/requests/{id}/status")
    public String updateRequestStatus(
            @PathVariable Long id,
            @RequestParam RequestStatus newStatus,
            @RequestParam(required = false) String adminNotes,
            @AuthenticationPrincipal UserDetails admin,
            RedirectAttributes redirectAttributes) {

        bloodRequestService.updateStatus(id, newStatus, adminNotes, admin.getUsername());
        redirectAttributes.addFlashAttribute("successMessage",
                "Request status updated to: " + newStatus.getDisplayName());
        return "redirect:/admin/requests/" + id;
    }

    // ============================================================
    // AUDIT LOG
    // ============================================================

    @GetMapping("/audit-log")
    public String auditLog(@RequestParam(defaultValue = "0") int page, Model model) {
        model.addAttribute("logs", auditLogService.findAll(page, 30));
        model.addAttribute("currentPage", page);
        model.addAttribute("pageTitle", "Audit Log — BloodBridge Admin");
        return "admin/audit-log";
    }
}
