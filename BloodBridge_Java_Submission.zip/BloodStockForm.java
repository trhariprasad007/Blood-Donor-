package com.bloodbridge.dto;

import com.bloodbridge.enums.BloodGroup;
import jakarta.validation.constraints.*;

/**
 * Form for admin to add or update a blood stock record.
 */
public class BloodStockForm {

    private Long bloodBankId;

    @NotNull(message = "Blood group is required.")
    private BloodGroup bloodGroup;

    @NotNull(message = "Unit count is required.")
    @Min(value = 0, message = "Units cannot be negative.")
    @Max(value = 99999, message = "Unit count seems unreasonably large. Please verify.")
    private Integer units;

    @Size(max = 500, message = "Remarks are too long (max 500 characters).")
    private String adminRemarks;

    // ========== Getters and Setters ==========

    public Long getBloodBankId() { return bloodBankId; }
    public void setBloodBankId(Long bloodBankId) { this.bloodBankId = bloodBankId; }

    public BloodGroup getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(BloodGroup bloodGroup) { this.bloodGroup = bloodGroup; }

    public Integer getUnits() { return units; }
    public void setUnits(Integer units) { this.units = units; }

    public String getAdminRemarks() { return adminRemarks; }
    public void setAdminRemarks(String adminRemarks) { this.adminRemarks = adminRemarks; }
}
