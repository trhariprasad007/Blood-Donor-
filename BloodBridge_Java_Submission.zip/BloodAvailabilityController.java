package com.bloodbridge.controller;

import com.bloodbridge.entity.BloodStock;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.service.BloodStockService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/**
 * Public blood availability / stock view controller.
 */
@Controller
@RequestMapping("/blood-availability")
public class BloodAvailabilityController {

    private final BloodStockService bloodStockService;

    public BloodAvailabilityController(BloodStockService bloodStockService) {
        this.bloodStockService = bloodStockService;
    }

    @GetMapping
    public String availability(
            @RequestParam(required = false) BloodGroup bloodGroup,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) String district,
            @RequestParam(defaultValue = "0") int page,
            Model model) {

        Page<BloodStock> stock = bloodStockService.findPublicAvailability(
                bloodGroup, state, district, page);

        model.addAttribute("stockPage", stock);
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("selectedBloodGroup", bloodGroup);
        model.addAttribute("selectedState", state);
        model.addAttribute("selectedDistrict", district);
        model.addAttribute("currentPage", page);
        model.addAttribute("pageTitle", "Blood Availability — BloodBridge");
        return "blood-availability";
    }
}
