package com.bloodbridge.controller;

import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.service.BloodBankService;
import com.bloodbridge.service.BloodRequestService;
import com.bloodbridge.service.BloodStockService;
import com.bloodbridge.service.DonorService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller for the public homepage.
 */
@Controller
public class HomeController {

    private final DonorService donorService;
    private final BloodBankService bloodBankService;
    private final BloodStockService bloodStockService;
    private final BloodRequestService bloodRequestService;

    public HomeController(DonorService donorService,
                          BloodBankService bloodBankService,
                          BloodStockService bloodStockService,
                          BloodRequestService bloodRequestService) {
        this.donorService = donorService;
        this.bloodBankService = bloodBankService;
        this.bloodStockService = bloodStockService;
        this.bloodRequestService = bloodRequestService;
    }

    @GetMapping("/")
    public String home(Model model) {
        // Database-backed statistics for the homepage
        model.addAttribute("totalDonors", donorService.countPubliclyEligible());
        model.addAttribute("totalBanks", bloodBankService.countVerified());
        model.addAttribute("totalRequests", bloodRequestService.countTotal());
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("pageTitle", "BloodBridge — Find Blood Donors & Blood Bank Availability");
        return "home";
    }

    @GetMapping("/about")
    public String about(Model model) {
        model.addAttribute("pageTitle", "About BloodBridge");
        return "about";
    }

    @GetMapping("/privacy")
    public String privacy(Model model) {
        model.addAttribute("pageTitle", "Privacy Notice — BloodBridge");
        return "privacy";
    }

    @GetMapping("/responsible-use")
    public String responsibleUse(Model model) {
        model.addAttribute("pageTitle", "Responsible Use — BloodBridge");
        return "responsible-use";
    }
}
