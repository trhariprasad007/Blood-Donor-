package com.bloodbridge.enums;

/**
 * Lifecycle status of a blood request.
 *
 * Valid transitions:
 *   PENDING → UNDER_REVIEW
 *   UNDER_REVIEW → IN_PROGRESS
 *   UNDER_REVIEW → REJECTED
 *   IN_PROGRESS → COMPLETED
 *   IN_PROGRESS → REJECTED
 *   PENDING → CANCELLED
 *   UNDER_REVIEW → CANCELLED
 */
public enum RequestStatus {
    PENDING("Pending"),
    UNDER_REVIEW("Under Review"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed"),
    REJECTED("Rejected"),
    CANCELLED("Cancelled");

    private final String displayName;

    RequestStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    /**
     * Returns true if the transition from this status to the given next status is valid.
     */
    public boolean canTransitionTo(RequestStatus next) {
        return switch (this) {
            case PENDING -> next == UNDER_REVIEW || next == CANCELLED;
            case UNDER_REVIEW -> next == IN_PROGRESS || next == REJECTED || next == CANCELLED;
            case IN_PROGRESS -> next == COMPLETED || next == REJECTED;
            // Terminal states: no further transitions
            case COMPLETED, REJECTED, CANCELLED -> false;
        };
    }

    @Override
    public String toString() {
        return displayName;
    }
}
