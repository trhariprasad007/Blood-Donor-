package com.bloodbridge.service;

import com.bloodbridge.entity.AuditLog;
import com.bloodbridge.repository.AuditLogRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service for recording and retrieving administrative audit log entries.
 * Provides a simple API for other services to record actions.
 */
@Service
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public AuditLogService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    @Transactional
    public void log(String adminUsername, String action,
                    String entityType, Long entityId, String description) {
        AuditLog entry = AuditLog.of(adminUsername, action, entityType, entityId, description);
        auditLogRepository.save(entry);
    }

    public Page<AuditLog> findAll(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return auditLogRepository.findAllByOrderByPerformedAtDesc(pageable);
    }

    public Page<AuditLog> findByAdmin(String adminUsername, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return auditLogRepository.findByAdminUsernameOrderByPerformedAtDesc(adminUsername, pageable);
    }
}
