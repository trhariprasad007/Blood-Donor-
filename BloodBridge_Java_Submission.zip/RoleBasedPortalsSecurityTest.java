package com.bloodbridge.security;

import com.bloodbridge.dto.DonorRegistrationForm;
import com.bloodbridge.dto.UserRegisterForm;
import com.bloodbridge.entity.AppUser;
import com.bloodbridge.entity.BloodRequest;
import com.bloodbridge.entity.Donor;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.DonorStatus;
import com.bloodbridge.enums.RequestStatus;
import com.bloodbridge.enums.UserRole;
import com.bloodbridge.service.BloodRequestService;
import com.bloodbridge.service.DonorService;
import com.bloodbridge.service.UserService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.formLogin;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class RoleBasedPortalsSecurityTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserService userService;

    @Autowired
    private DonorService donorService;

    @Autowired
    private BloodRequestService bloodRequestService;

    @Test
    @DisplayName("Donor login redirects to /donor/dashboard and NOT admin dashboard")
    void testDonorLoginRedirectsToDonorDashboard() throws Exception {
        UserRegisterForm form = new UserRegisterForm();
        form.setUsername("testdonorlogin");
        form.setPassword("Password123");
        form.setFullName("Test Donor Login");
        userService.register(form, UserRole.DONOR);

        mockMvc.perform(formLogin("/login").user("testdonorlogin").password("Password123"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/donor/dashboard"));
    }

    @Test
    @DisplayName("Requester login redirects to /requester/dashboard and NOT admin dashboard")
    void testRequesterLoginRedirectsToRequesterDashboard() throws Exception {
        UserRegisterForm form = new UserRegisterForm();
        form.setUsername("testrequesterlogin");
        form.setPassword("Password123");
        form.setFullName("Test Requester Login");
        userService.register(form, UserRole.REQUESTER);

        mockMvc.perform(formLogin("/login").user("testrequesterlogin").password("Password123"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/requester/dashboard"));
    }

    @Test
    @DisplayName("Admin login redirects to /admin/dashboard")
    void testAdminLoginRedirectsToAdminDashboard() throws Exception {
        mockMvc.perform(formLogin("/login").user("testadmin").password("TestAdmin@123"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/dashboard"));
    }

    @Test
    @WithMockUser(username = "donorUser", roles = {"DONOR"})
    @DisplayName("Donors cannot access admin pages and are redirected safely")
    void testDonorCannotAccessAdminDashboard() throws Exception {
        mockMvc.perform(get("/admin/dashboard"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/donor/dashboard"));
    }

    @Test
    @WithMockUser(username = "requesterUser", roles = {"REQUESTER"})
    @DisplayName("Requesters cannot access admin pages and are redirected safely")
    void testRequesterCannotAccessAdminDashboard() throws Exception {
        mockMvc.perform(get("/admin/dashboard"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/requester/dashboard"));
    }

    @Test
    @WithMockUser(username = "donorA", roles = {"DONOR"})
    @DisplayName("Donor dashboard only displays their own records, not another donor's records")
    void testDonorDashboardDataIsolation() throws Exception {
        UserRegisterForm userAForm = new UserRegisterForm();
        userAForm.setUsername("donorA");
        userAForm.setPassword("Pass1234");
        userAForm.setFullName("Alice Donor");
        AppUser userA = userService.register(userAForm, UserRole.DONOR);

        UserRegisterForm userBForm = new UserRegisterForm();
        userBForm.setUsername("donorB");
        userBForm.setPassword("Pass1234");
        userBForm.setFullName("Bob Donor");
        AppUser userB = userService.register(userBForm, UserRole.DONOR);

        DonorRegistrationForm regA = new DonorRegistrationForm();
        regA.setFullName("Alice Donor");
        regA.setBloodGroup(BloodGroup.A_POSITIVE);
        regA.setAge(25);
        regA.setState("StateA");
        regA.setDistrict("DistrictA");
        regA.setCity("CityAlpha");
        regA.setPhone("9900000001");
        donorService.registerDonor(regA, userA.getId());

        DonorRegistrationForm regB = new DonorRegistrationForm();
        regB.setFullName("Bob Donor");
        regB.setBloodGroup(BloodGroup.B_POSITIVE);
        regB.setAge(30);
        regB.setState("StateB");
        regB.setDistrict("DistrictB");
        regB.setCity("CityBeta");
        regB.setPhone("9900000002");
        donorService.registerDonor(regB, userB.getId());

        mockMvc.perform(get("/donor/dashboard"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("CityAlpha")))
                .andExpect(content().string(not(containsString("CityBeta"))));
    }

    @Test
    @WithMockUser(username = "reqA", roles = {"REQUESTER"})
    @DisplayName("Requester dashboard only displays their own requests, not another requester's requests")
    void testRequesterDashboardDataIsolation() throws Exception {
        UserRegisterForm reqAForm = new UserRegisterForm();
        reqAForm.setUsername("reqA");
        reqAForm.setPassword("Pass1234");
        reqAForm.setFullName("Requester One");
        AppUser userReqA = userService.register(reqAForm, UserRole.REQUESTER);

        UserRegisterForm reqBForm = new UserRegisterForm();
        reqBForm.setUsername("reqB");
        reqBForm.setPassword("Pass1234");
        reqBForm.setFullName("Requester Two");
        AppUser userReqB = userService.register(reqBForm, UserRole.REQUESTER);

        com.bloodbridge.dto.BloodRequestForm formA = new com.bloodbridge.dto.BloodRequestForm();
        formA.setRequesterName("Requester One");
        formA.setBloodGroup(BloodGroup.O_POSITIVE);
        formA.setUnitsRequired(3);
        formA.setState("Tamil Nadu");
        formA.setDistrict("Chennai");
        formA.setCity("SpecialHospitalA");
        formA.setRequesterPhone("9900000003");
        bloodRequestService.submitRequest(formA, userReqA.getId());

        com.bloodbridge.dto.BloodRequestForm formB = new com.bloodbridge.dto.BloodRequestForm();
        formB.setRequesterName("Requester Two");
        formB.setBloodGroup(BloodGroup.AB_POSITIVE);
        formB.setUnitsRequired(1);
        formB.setState("Karnataka");
        formB.setDistrict("Bangalore");
        formB.setCity("SpecialHospitalB");
        formB.setRequesterPhone("9900000004");
        bloodRequestService.submitRequest(formB, userReqB.getId());

        mockMvc.perform(get("/requester/dashboard"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("SpecialHospitalA")))
                .andExpect(content().string(not(containsString("SpecialHospitalB"))));
    }
}
