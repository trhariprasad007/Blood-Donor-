package com.bloodbridge.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class PublicWebFlowIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Homepage renders with key branding and metrics")
    void testHomepageRenders() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("home"))
                .andExpect(content().string(containsString("BloodBridge")))
                .andExpect(content().string(containsString("Find Blood Donors")));
    }

    @Test
    @DisplayName("About page renders educational project disclaimer")
    void testAboutPageRenders() throws Exception {
        mockMvc.perform(get("/about"))
                .andExpect(status().isOk())
                .andExpect(view().name("about"))
                .andExpect(content().string(containsString("About BloodBridge")));
    }

    @Test
    @DisplayName("Privacy page renders strict data privacy policies")
    void testPrivacyPageRenders() throws Exception {
        mockMvc.perform(get("/privacy"))
                .andExpect(status().isOk())
                .andExpect(view().name("privacy"))
                .andExpect(content().string(containsString("Privacy Notice")));
    }

    @Test
    @DisplayName("Responsible use page renders safety disclaimers")
    void testResponsibleUsePageRenders() throws Exception {
        mockMvc.perform(get("/responsible-use"))
                .andExpect(status().isOk())
                .andExpect(view().name("responsible-use"))
                .andExpect(content().string(containsString("Responsible Use")));
    }

    @Test
    @DisplayName("Blood bank directory renders")
    void testBloodBankDirectoryRenders() throws Exception {
        mockMvc.perform(get("/blood-banks"))
                .andExpect(status().isOk())
                .andExpect(view().name("blood-banks/list"))
                .andExpect(content().string(containsString("Blood Bank Directory")));
    }

    @Test
    @DisplayName("Blood availability page renders with filter dropdowns")
    void testBloodAvailabilityPageRenders() throws Exception {
        mockMvc.perform(get("/blood-availability"))
                .andExpect(status().isOk())
                .andExpect(view().name("blood-availability"))
                .andExpect(content().string(containsString("Blood Availability")));
    }

    @Test
    @DisplayName("Donor registration form renders with consent checkboxes")
    void testDonorRegistrationFormRenders() throws Exception {
        mockMvc.perform(get("/donors/register"))
                .andExpect(status().isOk())
                .andExpect(view().name("donors/register"))
                .andExpect(content().string(containsString("Register as a Blood Donor")));
    }

    @Test
    @DisplayName("Blood request form renders with emergency disclaimer")
    void testBloodRequestFormRenders() throws Exception {
        mockMvc.perform(get("/blood-requests/new"))
                .andExpect(status().isOk())
                .andExpect(view().name("blood-requests/new"))
                .andExpect(content().string(containsString("Request Blood")));
    }

    @Test
    @DisplayName("Admin login page renders without authentication required")
    void testAdminLoginPageRenders() throws Exception {
        mockMvc.perform(get("/admin/login"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/login"))
                .andExpect(content().string(containsString("Admin Login")));
    }

    @Test
    @DisplayName("Favicon is served as static resource")
    void testFaviconIsServed() throws Exception {
        mockMvc.perform(get("/favicon.ico"))
                .andExpect(status().isOk());
    }
}
