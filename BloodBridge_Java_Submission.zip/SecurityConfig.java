package com.bloodbridge.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;

/**
 * Spring Security configuration for BloodBridge.
 *
 * Distinct roles:
 * - ROLE_ADMIN (/admin/**)
 * - ROLE_DONOR (/donor/**)
 * - ROLE_REQUESTER (/requester/**)
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http,
                                                    CustomUserDetailsService customUserDetailsService,
                                                    CustomAuthenticationSuccessHandler successHandler) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                // Static assets
                .requestMatchers("/css/**", "/js/**", "/images/**", "/favicon.ico").permitAll()
                // Error pages
                .requestMatchers("/error/**", "/error").permitAll()
                // Public pages
                .requestMatchers("/").permitAll()
                .requestMatchers("/donors", "/donors/register", "/donors/register/success").permitAll()
                .requestMatchers("/blood-banks", "/blood-banks/**").permitAll()
                .requestMatchers("/blood-availability").permitAll()
                .requestMatchers("/blood-requests/new", "/blood-requests/submit", "/blood-requests/confirmation").permitAll()
                .requestMatchers("/about", "/privacy", "/responsible-use").permitAll()

                // Portal logins and registrations
                .requestMatchers("/admin/login").permitAll()
                .requestMatchers("/donor/login", "/donor/register").permitAll()
                .requestMatchers("/requester/login", "/requester/register").permitAll()

                // Protected Portals
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/donor/**").hasRole("DONOR")
                .requestMatchers("/requester/**").hasRole("REQUESTER")

                .anyRequest().permitAll()
            )

            .formLogin(form -> form
                .loginPage("/admin/login")
                .loginProcessingUrl("/login")
                .successHandler(successHandler)
                .failureHandler((req, res, exp) -> {
                    String referer = req.getHeader("Referer");
                    if (referer != null && referer.contains("/donor/login")) {
                        res.sendRedirect("/donor/login?error=true");
                    } else if (referer != null && referer.contains("/requester/login")) {
                        res.sendRedirect("/requester/login?error=true");
                    } else {
                        res.sendRedirect("/admin/login?error=true");
                    }
                })
                .usernameParameter("username")
                .passwordParameter("password")
                .permitAll()
            )

            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/?logout=true")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
            )

            .exceptionHandling(ex -> ex
                .accessDeniedHandler((req, res, accessDeniedException) -> {
                    // If user is authenticated, redirect them safely to their own portal dashboard or 403
                    var auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
                    if (auth != null) {
                        for (var authority : auth.getAuthorities()) {
                            if ("ROLE_DONOR".equals(authority.getAuthority())) {
                                res.sendRedirect("/donor/dashboard");
                                return;
                            } else if ("ROLE_REQUESTER".equals(authority.getAuthority())) {
                                res.sendRedirect("/requester/dashboard");
                                return;
                            } else if ("ROLE_ADMIN".equals(authority.getAuthority())) {
                                res.sendRedirect("/admin/dashboard");
                                return;
                            }
                        }
                    }
                    res.sendRedirect("/error/403");
                })
            )

            .userDetailsService(customUserDetailsService)

            .headers(headers -> headers
                .frameOptions(frame -> frame.deny())
                .contentTypeOptions(ct -> {})
                .referrerPolicy(rp -> rp.policy(
                    ReferrerPolicyHeaderWriter.ReferrerPolicy.STRICT_ORIGIN_WHEN_CROSS_ORIGIN))
            );

        return http.build();
    }
}
