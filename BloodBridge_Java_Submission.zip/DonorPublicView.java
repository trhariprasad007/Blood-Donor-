package com.bloodbridge.dto;

import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.DonorStatus;

import java.time.LocalDateTime;

/**
 * Safe public view of a donor record.
 * Contains ONLY information that is safe to show publicly.
 * NEVER includes phone, email, full address, or other private data.
 */
public class DonorPublicView {

    private Long id;
    private String displayName;     // e.g., "Rajesh K." — not full name
    private BloodGroup bloodGroup;
    private String city;
    private String district;
    private String state;
    private Boolean available;
    private LocalDateTime updatedAt;

    // Constructor

    public DonorPublicView(Long id, String displayName, BloodGroup bloodGroup,
                           String city, String district, String state,
                           Boolean available, LocalDateTime updatedAt) {
        this.id = id;
        this.displayName = displayName;
        this.bloodGroup = bloodGroup;
        this.city = city;
        this.district = district;
        this.state = state;
        this.available = available;
        this.updatedAt = updatedAt;
    }

    // Getters (no setters needed - immutable view)

    public Long getId() { return id; }
    public String getDisplayName() { return displayName; }
    public BloodGroup getBloodGroup() { return bloodGroup; }
    public String getCity() { return city; }
    public String getDistrict() { return district; }
    public String getState() { return state; }
    public Boolean getAvailable() { return available; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
