package com.bloodbridge.enums;

public enum UserRole {
    DONOR,
    REQUESTER,
    ADMIN
}
