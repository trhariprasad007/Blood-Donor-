package com.bloodbridge.service;

import com.bloodbridge.entity.BloodBank;
import com.bloodbridge.entity.BloodRequest;
import com.bloodbridge.entity.BloodStock;
import com.bloodbridge.entity.Donor;
import com.bloodbridge.enums.*;
import com.bloodbridge.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Loads fictional demonstration data for development and college demonstration.
 *
 * IMPORTANT:
 * - Only runs when app.demo-data.enabled=true
 * - Uses idempotent checks to prevent duplicate data on restart
 * - All names, phone numbers, banks, and data are fictional
 * - Do NOT use in production with real data
 *
 * Runs after AdminBootstrapService (Order=10 vs Order=5 default).
 */
@Service
@Order(10)
public class DemoDataService {

    private static final Logger logger = LoggerFactory.getLogger(DemoDataService.class);

    @Value("${app.demo-data.enabled:false}")
    private boolean demoDataEnabled;

    private final DonorRepository donorRepository;
    private final BloodBankRepository bloodBankRepository;
    private final BloodStockRepository bloodStockRepository;
    private final BloodRequestRepository bloodRequestRepository;

    public DemoDataService(DonorRepository donorRepository,
                           BloodBankRepository bloodBankRepository,
                           BloodStockRepository bloodStockRepository,
                           BloodRequestRepository bloodRequestRepository) {
        this.donorRepository = donorRepository;
        this.bloodBankRepository = bloodBankRepository;
        this.bloodStockRepository = bloodStockRepository;
        this.bloodRequestRepository = bloodRequestRepository;
    }

    @EventListener(ApplicationReadyEvent.class)
    @Transactional
    public void loadDemoData() {
        if (!demoDataEnabled) {
            logger.info("Demo data disabled (app.demo-data.enabled=false). Skipping.");
            return;
        }

        logger.info("Loading demonstration data (fictional — for educational purposes only)...");

        loadDemoDonors();
        BloodBank[] banks = loadDemoBloodBanks();
        if (banks != null) {
            loadDemoBloodStock(banks);
        }
        loadDemoBloodRequests();

        logger.info("Demonstration data loading complete.");
    }

    // ============================================================
    // DEMO DONORS
    // ============================================================

    private void loadDemoDonors() {
        // Idempotent check
        if (donorRepository.existsByFullName("Arjun Demo Sharma")) {
            logger.debug("Demo donors already exist. Skipping.");
            return;
        }

        // Verified, publicly listed, available donor
        createDonor("Arjun Demo Sharma", BloodGroup.O_POSITIVE, 28,
                "Tamil Nadu", "Chennai", "Adyar",
                "9876543210", null,
                true, true, DonorStatus.VERIFIED, true);

        // Verified, publicly listed, available donor (different group)
        createDonor("Priya Demo Nair", BloodGroup.A_POSITIVE, 25,
                "Kerala", "Ernakulam", "Kakkanad",
                "9876543211", "priya.demo@example.com",
                true, true, DonorStatus.VERIFIED, true);

        // Verified, publicly listed, but NOT available
        createDonor("Ravi Demo Kumar", BloodGroup.B_POSITIVE, 35,
                "Karnataka", "Bengaluru", "Koramangala",
                "9876543212", null,
                false, true, DonorStatus.VERIFIED, true);

        // Verified but did NOT consent to public listing
        createDonor("Sneha Demo Patel", BloodGroup.AB_POSITIVE, 30,
                "Maharashtra", "Pune", "Kothrud",
                "9876543213", null,
                true, false, DonorStatus.VERIFIED, true);

        // PENDING — awaiting admin review (should not appear publicly)
        createDonor("Vikram Demo Singh", BloodGroup.O_NEGATIVE, 22,
                "Delhi", "New Delhi", "Dwarka",
                "9876543214", null,
                true, true, DonorStatus.PENDING, true);

        // Another verified and available donor
        createDonor("Lakshmi Demo Reddy", BloodGroup.A_NEGATIVE, 32,
                "Andhra Pradesh", "Vijayawada", "Benz Circle",
                "9876543215", null,
                true, true, DonorStatus.VERIFIED, true);

        // Verified, available, B-negative (rare group)
        createDonor("Mohammed Demo Ali", BloodGroup.B_NEGATIVE, 40,
                "Telangana", "Hyderabad", "Jubilee Hills",
                "9876543216", null,
                true, true, DonorStatus.VERIFIED, true);

        // AB-negative (rarest group)
        createDonor("Deepika Demo Rao", BloodGroup.AB_NEGATIVE, 27,
                "Tamil Nadu", "Coimbatore", "RS Puram",
                "9876543217", null,
                true, true, DonorStatus.VERIFIED, true);

        logger.info("Demo donors loaded (8 fictional records).");
    }

    private Donor createDonor(String name, BloodGroup bg, int age,
                               String state, String district, String city,
                               String phone, String email,
                               boolean available, boolean consentPublic,
                               DonorStatus status, boolean active) {
        Donor d = new Donor();
        d.setFullName(name);
        d.setBloodGroup(bg);
        d.setAge(age);
        d.setState(state);
        d.setDistrict(district);
        d.setCity(city);
        d.setPhone(phone);
        d.setEmail(email);
        d.setAvailable(available);
        d.setConsentDataProcessing(true);
        d.setConsentPublicListing(consentPublic);
        d.setInformationAccurateConfirmation(true);
        d.setStatus(status);
        d.setActive(active);
        d.setAdminNotes("[DEMO] Fictional demonstration record");
        return donorRepository.save(d);
    }

    // ============================================================
    // DEMO BLOOD BANKS
    // ============================================================

    private BloodBank[] loadDemoBloodBanks() {
        if (bloodBankRepository.existsByName("City Care Blood Centre (Demo)")) {
            logger.debug("Demo blood banks already exist. Skipping.");
            return null;
        }

        BloodBank bank1 = createBank(
                "City Care Blood Centre (Demo)",
                "123 Demo Street, Adyar", "Tamil Nadu", "Chennai", "Adyar",
                "04412345001", "info@citycaredemo.example", "https://example.com",
                BankStatus.VERIFIED, true);

        BloodBank bank2 = createBank(
                "Lifeline Blood Bank (Demo)",
                "456 Demo Avenue, Kakkanad", "Kerala", "Ernakulam", "Kakkanad",
                "04842345002", null, null,
                BankStatus.VERIFIED, true);

        BloodBank bank3 = createBank(
                "Hope Blood Services (Demo)",
                "789 Demo Road, Koramangala", "Karnataka", "Bengaluru", "Koramangala",
                "08023450003", null, null,
                BankStatus.PENDING, true);

        logger.info("Demo blood banks loaded (3 fictional records, 2 verified).");
        return new BloodBank[]{bank1, bank2, bank3};
    }

    private BloodBank createBank(String name, String address,
                                  String state, String district, String city,
                                  String phone, String email, String website,
                                  BankStatus status, boolean active) {
        BloodBank b = new BloodBank();
        b.setName(name);
        b.setAddress(address);
        b.setState(state);
        b.setDistrict(district);
        b.setCity(city);
        b.setContactPhone(phone);
        b.setContactEmail(email);
        b.setWebsiteUrl(website);
        b.setStatus(status);
        b.setActive(active);
        b.setAdminNotes("[DEMO] Fictional demonstration bank");
        return bloodBankRepository.save(b);
    }

    // ============================================================
    // DEMO BLOOD STOCK
    // ============================================================

    private void loadDemoBloodStock(BloodBank[] banks) {
        BloodBank bank1 = banks[0];
        BloodBank bank2 = banks[1];

        // Stock for bank1 (verified)
        createStock(bank1, BloodGroup.A_POSITIVE, 15);
        createStock(bank1, BloodGroup.A_NEGATIVE, 4);
        createStock(bank1, BloodGroup.B_POSITIVE, 22);
        createStock(bank1, BloodGroup.B_NEGATIVE, 2);
        createStock(bank1, BloodGroup.AB_POSITIVE, 8);
        createStock(bank1, BloodGroup.AB_NEGATIVE, 0);  // zero units — distinguishable from "not reported"
        createStock(bank1, BloodGroup.O_POSITIVE, 30);
        createStock(bank1, BloodGroup.O_NEGATIVE, 6);

        // Stock for bank2 (verified)
        createStock(bank2, BloodGroup.A_POSITIVE, 10);
        createStock(bank2, BloodGroup.B_POSITIVE, 18);
        createStock(bank2, BloodGroup.O_POSITIVE, 25);
        createStock(bank2, BloodGroup.O_NEGATIVE, 3);

        // bank3 is PENDING — no stock shown publicly

        logger.info("Demo blood stock loaded (12 fictional records).");
    }

    private void createStock(BloodBank bank, BloodGroup bg, int units) {
        if (!bloodStockRepository.existsByBloodBankAndBloodGroup(bank, bg)) {
            BloodStock s = new BloodStock();
            s.setBloodBank(bank);
            s.setBloodGroup(bg);
            s.setUnits(units);
            s.setAdminRemarks("[DEMO] Fictional demonstration data");
            bloodStockRepository.save(s);
        }
    }

    // ============================================================
    // DEMO BLOOD REQUESTS
    // ============================================================

    private void loadDemoBloodRequests() {
        if (bloodRequestRepository.count() > 0) {
            logger.debug("Demo blood requests already exist. Skipping.");
            return;
        }

        createRequest("Ramesh Demo", BloodGroup.O_POSITIVE, 2,
                "Tamil Nadu", "Chennai", "Adyar", "General Hospital Demo",
                "9123456001", RequestStatus.PENDING);

        createRequest("Kavitha Demo", BloodGroup.A_POSITIVE, 1,
                "Kerala", "Ernakulam", "Kakkanad", null,
                "9123456002", RequestStatus.UNDER_REVIEW);

        createRequest("Suresh Demo", BloodGroup.B_NEGATIVE, 3,
                "Karnataka", "Bengaluru", "Koramangala", "Demo Medical Centre",
                "9123456003", RequestStatus.COMPLETED);

        logger.info("Demo blood requests loaded (3 fictional records).");
    }

    private void createRequest(String name, BloodGroup bg, int units,
                                String state, String district, String city,
                                String hospital, String phone, RequestStatus status) {
        BloodRequest r = new BloodRequest();
        r.setRequesterName(name);
        r.setBloodGroup(bg);
        r.setUnitsRequired(units);
        r.setState(state);
        r.setDistrict(district);
        r.setCity(city);
        r.setHospitalName(hospital);
        r.setRequesterPhone(phone);
        r.setStatus(status);
        r.setAdminNotes("[DEMO] Fictional demonstration request");
        bloodRequestRepository.save(r);
    }
}
