package com.bloodbridge.controller;

import com.bloodbridge.dto.DonorRegistrationForm;
import com.bloodbridge.entity.Donor;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.DonorStatus;
import com.bloodbridge.repository.DonorRepository;
import com.bloodbridge.service.DonorService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class DonorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private DonorService donorService;

    @Autowired
    private DonorRepository donorRepository;

    @Test
    @DisplayName("Find Donors page renders successfully when verified donors exist")
    void testFindDonorsPageRendersWithDonors() throws Exception {
        // Register a donor
        DonorRegistrationForm form = new DonorRegistrationForm();
        form.setFullName("Test Public Donor");
        form.setBloodGroup(BloodGroup.O_POSITIVE);
        form.setAge(25);
        form.setState("Tamil Nadu");
        form.setDistrict("Chennai");
        form.setCity("Adyar");
        form.setPhone("9876543210");
        form.setEmail("donor@example.com");
        form.setConsentDataProcessing(true);
        form.setConsentPublicListing(true);
        form.setInformationAccurateConfirmation(true);

        Long donorId = donorService.registerDonor(form);

        // Verify the donor so they appear in public search (donors.totalElements > 0)
        donorService.verifyDonor(donorId, "Admin verification", "admin");

        // Now perform GET /donors
        mockMvc.perform(get("/donors"))
                .andExpect(status().isOk())
                .andExpect(view().name("donors/search"))
                .andExpect(model().attributeExists("donors"))
                .andExpect(content().string(containsString("1 donor(s) found")))
                .andExpect(content().string(containsString("Test D.")))
                .andExpect(content().string(containsString("Adyar, Chennai")));
    }
}
