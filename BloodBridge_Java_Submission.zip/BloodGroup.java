package com.bloodbridge.enums;

/**
 * Standard ABO/Rh blood group system.
 * These are the eight universally recognized blood groups.
 */
public enum BloodGroup {
    A_POSITIVE("A+"),
    A_NEGATIVE("A-"),
    B_POSITIVE("B+"),
    B_NEGATIVE("B-"),
    AB_POSITIVE("AB+"),
    AB_NEGATIVE("AB-"),
    O_POSITIVE("O+"),
    O_NEGATIVE("O-");

    private final String displayName;

    BloodGroup(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    /**
     * Find a BloodGroup by its display name (e.g., "A+").
     * Returns null if not found.
     */
    public static BloodGroup fromDisplayName(String displayName) {
        if (displayName == null) return null;
        for (BloodGroup bg : values()) {
            if (bg.displayName.equalsIgnoreCase(displayName)) {
                return bg;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
