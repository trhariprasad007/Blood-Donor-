package com.bloodbridge.controller;

import com.bloodbridge.dto.BloodRequestForm;
import com.bloodbridge.dto.UserRegisterForm;
import com.bloodbridge.entity.AppUser;
import com.bloodbridge.entity.BloodRequest;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.UserRole;
import com.bloodbridge.service.BloodRequestService;
import com.bloodbridge.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/requester")
public class RequesterPortalController {

    private final UserService userService;
    private final BloodRequestService bloodRequestService;

    public RequesterPortalController(UserService userService, BloodRequestService bloodRequestService) {
        this.userService = userService;
        this.bloodRequestService = bloodRequestService;
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("pageTitle", "Requester Login — BloodBridge");
        return "requester/login";
    }

    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("userForm", new UserRegisterForm());
        model.addAttribute("pageTitle", "Requester Signup — BloodBridge");
        return "requester/register";
    }

    @PostMapping("/register")
    public String processRegister(@Valid @ModelAttribute("userForm") UserRegisterForm form,
                                  BindingResult bindingResult,
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("pageTitle", "Requester Signup — BloodBridge");
            return "requester/register";
        }
        try {
            userService.register(form, UserRole.REQUESTER);
            redirectAttributes.addFlashAttribute("successMessage", "Account created successfully! Please sign in.");
            return "redirect:/requester/login";
        } catch (Exception ex) {
            model.addAttribute("errorMessage", ex.getMessage());
            model.addAttribute("pageTitle", "Requester Signup — BloodBridge");
            return "requester/register";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        AppUser user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalStateException("User not found: " + userDetails.getUsername()));

        List<BloodRequest> requests = bloodRequestService.findByUserId(user.getId());
        model.addAttribute("user", user);
        model.addAttribute("requests", requests);
        model.addAttribute("pageTitle", "Requester Portal Dashboard — BloodBridge");
        return "requester/dashboard";
    }

    @GetMapping("/new-request")
    public String showNewRequestForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        AppUser user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalStateException("User not found: " + userDetails.getUsername()));

        BloodRequestForm form = new BloodRequestForm();
        form.setRequesterName(user.getFullName());
        form.setRequesterEmail(user.getEmail());
        form.setRequesterPhone(user.getPhone() != null ? user.getPhone() : "");

        model.addAttribute("requestForm", form);
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("pageTitle", "Create Blood Request — BloodBridge");
        return "requester/new-request";
    }

    @PostMapping("/new-request")
    public String submitNewRequest(@AuthenticationPrincipal UserDetails userDetails,
                                  @Valid @ModelAttribute("requestForm") BloodRequestForm form,
                                  BindingResult bindingResult,
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        AppUser user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalStateException("User not found: " + userDetails.getUsername()));

        if (bindingResult.hasErrors()) {
            model.addAttribute("bloodGroups", BloodGroup.values());
            model.addAttribute("pageTitle", "Create Blood Request — BloodBridge");
            return "requester/new-request";
        }

        bloodRequestService.submitRequest(form, user.getId());
        redirectAttributes.addFlashAttribute("successMessage",
                "Your blood request has been submitted and is pending review.");
        return "redirect:/requester/dashboard";
    }
}
