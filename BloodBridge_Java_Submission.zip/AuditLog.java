package com.bloodbridge.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Audit log entry for administrator actions.
 *
 * Records meaningful actions such as:
 * - Verifying/rejecting donor registrations
 * - Verifying/rejecting blood banks
 * - Updating blood stock
 * - Changing blood request status
 * - Activating/deactivating listings
 *
 * NEVER logs: passwords, private contact details, sensitive personal info
 */
@Entity
@Table(name = "audit_logs", indexes = {
        @Index(name = "idx_audit_admin", columnList = "admin_username"),
        @Index(name = "idx_audit_action_time", columnList = "performed_at"),
        @Index(name = "idx_audit_entity", columnList = "entity_type, entity_id")
})
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Username of the administrator who performed the action */
    @Column(name = "admin_username", nullable = false, length = 50)
    private String adminUsername;

    /** Short action code, e.g., "DONOR_VERIFIED", "STOCK_UPDATED" */
    @Column(name = "action", nullable = false, length = 100)
    private String action;

    /** Type of entity affected, e.g., "DONOR", "BLOOD_BANK", "BLOOD_STOCK", "BLOOD_REQUEST" */
    @Column(name = "entity_type", length = 50)
    private String entityType;

    /** ID of the affected entity */
    @Column(name = "entity_id")
    private Long entityId;

    /** Human-readable description of the action (safe, no private data) */
    @Column(name = "description", length = 1000)
    private String description;

    @Column(name = "performed_at", nullable = false, updatable = false)
    private LocalDateTime performedAt;

    @PrePersist
    protected void onCreate() {
        performedAt = LocalDateTime.now();
    }

    // ========== Constructor helpers ==========

    public static AuditLog of(String adminUsername, String action,
                               String entityType, Long entityId, String description) {
        AuditLog log = new AuditLog();
        log.adminUsername = adminUsername;
        log.action = action;
        log.entityType = entityType;
        log.entityId = entityId;
        log.description = description;
        return log;
    }

    // ========== Getters and Setters ==========

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getAdminUsername() { return adminUsername; }
    public void setAdminUsername(String adminUsername) { this.adminUsername = adminUsername; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getEntityType() { return entityType; }
    public void setEntityType(String entityType) { this.entityType = entityType; }

    public Long getEntityId() { return entityId; }
    public void setEntityId(Long entityId) { this.entityId = entityId; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public LocalDateTime getPerformedAt() { return performedAt; }
    public void setPerformedAt(LocalDateTime performedAt) { this.performedAt = performedAt; }
}
