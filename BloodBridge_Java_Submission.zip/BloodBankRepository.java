package com.bloodbridge.repository;

import com.bloodbridge.entity.BloodBank;
import com.bloodbridge.enums.BankStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface BloodBankRepository extends JpaRepository<BloodBank, Long> {

    /**
     * Find publicly visible banks: VERIFIED and active, with optional location/name filters.
     */
    @Query("""
            SELECT b FROM BloodBank b
            WHERE b.status = 'VERIFIED'
              AND b.active = true
              AND (:name IS NULL OR LOWER(b.name) LIKE LOWER(CONCAT('%', :name, '%')))
              AND (:state IS NULL OR LOWER(b.state) LIKE LOWER(CONCAT('%', :state, '%')))
              AND (:district IS NULL OR LOWER(b.district) LIKE LOWER(CONCAT('%', :district, '%')))
              AND (:city IS NULL OR LOWER(b.city) LIKE LOWER(CONCAT('%', :city, '%')))
            ORDER BY b.name ASC
            """)
    Page<BloodBank> findPubliclyVisible(
            @Param("name") String name,
            @Param("state") String state,
            @Param("district") String district,
            @Param("city") String city,
            Pageable pageable);

    /** Count by status for admin dashboard */
    long countByStatus(BankStatus status);

    /** Count verified and active banks */
    @Query("SELECT COUNT(b) FROM BloodBank b WHERE b.status = 'VERIFIED' AND b.active = true")
    long countVerifiedActive();

    /** Admin: find all banks with optional status filter */
    @Query("""
            SELECT b FROM BloodBank b
            WHERE (:status IS NULL OR b.status = :status)
            ORDER BY b.createdAt DESC
            """)
    Page<BloodBank> findAllByStatusFilter(@Param("status") BankStatus status, Pageable pageable);

    /** Check if demo data exists */
    boolean existsByName(String name);
}
