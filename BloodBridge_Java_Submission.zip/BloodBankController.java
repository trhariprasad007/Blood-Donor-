package com.bloodbridge.controller;

import com.bloodbridge.entity.BloodBank;
import com.bloodbridge.entity.BloodStock;
import com.bloodbridge.service.BloodBankService;
import com.bloodbridge.service.BloodStockService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Public blood bank directory controller.
 * Only shows VERIFIED and active banks.
 */
@Controller
@RequestMapping("/blood-banks")
public class BloodBankController {

    private final BloodBankService bloodBankService;
    private final BloodStockService bloodStockService;

    public BloodBankController(BloodBankService bloodBankService,
                                BloodStockService bloodStockService) {
        this.bloodBankService = bloodBankService;
        this.bloodStockService = bloodStockService;
    }

    @GetMapping
    public String listBanks(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) String district,
            @RequestParam(required = false) String city,
            @RequestParam(defaultValue = "0") int page,
            Model model) {

        Page<BloodBank> banks = bloodBankService.searchPublic(name, state, district, city, page);

        model.addAttribute("banks", banks);
        model.addAttribute("searchName", name);
        model.addAttribute("selectedState", state);
        model.addAttribute("selectedDistrict", district);
        model.addAttribute("selectedCity", city);
        model.addAttribute("currentPage", page);
        model.addAttribute("pageTitle", "Blood Bank Directory — BloodBridge");
        return "blood-banks/list";
    }

    @GetMapping("/{id}")
    public String bankDetail(@PathVariable Long id, Model model) {
        // getPublicBank() throws ResourceNotFoundException if not publicly visible
        BloodBank bank = bloodBankService.getPublicBank(id);
        List<BloodStock> stock = bloodStockService.getStockForPublicBank(id);

        model.addAttribute("bank", bank);
        model.addAttribute("stock", stock);
        model.addAttribute("pageTitle", bank.getName() + " — BloodBridge");
        return "blood-banks/detail";
    }
}
