package com.bloodbridge.dto;

import com.bloodbridge.enums.BloodGroup;
import jakarta.validation.constraints.*;

/**
 * Form object for donor registration submitted by the public.
 * Validated in the browser (client-side) and on the server (mandatory).
 * Never use this DTO to expose entity data publicly.
 */
public class DonorRegistrationForm {

    @NotBlank(message = "Full name is required.")
    @Size(min = 2, max = 100, message = "Full name must be between 2 and 100 characters.")
    @Pattern(regexp = "^[a-zA-Z\\s.'-]+$", message = "Full name contains invalid characters.")
    private String fullName;

    @NotNull(message = "Blood group is required.")
    private BloodGroup bloodGroup;

    @NotNull(message = "Age is required.")
    @Min(value = 18, message = "You must be at least 18 years old to register as a donor.")
    @Max(value = 65, message = "Age must be 65 or below.")
    private Integer age;

    @NotBlank(message = "State is required.")
    @Size(max = 100, message = "State name is too long.")
    private String state;

    @NotBlank(message = "District is required.")
    @Size(max = 100, message = "District name is too long.")
    private String district;

    @NotBlank(message = "City or locality is required.")
    @Size(max = 100, message = "City name is too long.")
    private String city;

    @NotBlank(message = "Phone number is required.")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Please enter a valid 10-digit Indian mobile number.")
    private String phone;

    @Email(message = "Please enter a valid email address.")
    @Size(max = 150, message = "Email address is too long.")
    private String email;

    private Boolean available = true;

    @AssertTrue(message = "You must consent to data processing to register.")
    private Boolean consentDataProcessing;

    private Boolean consentPublicListing = false;

    @AssertTrue(message = "You must confirm that your information is accurate.")
    private Boolean informationAccurateConfirmation;

    // ========== Getters and Setters ==========

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public BloodGroup getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(BloodGroup bloodGroup) { this.bloodGroup = bloodGroup; }

    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Boolean getAvailable() { return available; }
    public void setAvailable(Boolean available) { this.available = available; }

    public Boolean getConsentDataProcessing() { return consentDataProcessing; }
    public void setConsentDataProcessing(Boolean consentDataProcessing) { this.consentDataProcessing = consentDataProcessing; }

    public Boolean getConsentPublicListing() { return consentPublicListing; }
    public void setConsentPublicListing(Boolean consentPublicListing) { this.consentPublicListing = consentPublicListing; }

    public Boolean getInformationAccurateConfirmation() { return informationAccurateConfirmation; }
    public void setInformationAccurateConfirmation(Boolean informationAccurateConfirmation) {
        this.informationAccurateConfirmation = informationAccurateConfirmation;
    }
}
