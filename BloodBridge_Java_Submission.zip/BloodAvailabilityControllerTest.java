package com.bloodbridge.controller;

import com.bloodbridge.entity.BloodBank;
import com.bloodbridge.entity.BloodStock;
import com.bloodbridge.enums.BankStatus;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.repository.BloodBankRepository;
import com.bloodbridge.repository.BloodStockRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class BloodAvailabilityControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BloodBankRepository bloodBankRepository;

    @Autowired
    private BloodStockRepository bloodStockRepository;

    @Test
    @DisplayName("Blood Availability page renders successfully when stock exists")
    void testBloodAvailabilityRendersWithStock() throws Exception {
        BloodBank bank = new BloodBank();
        bank.setName("City Red Cross Blood Bank");
        bank.setAddress("123 Hospital Road");
        bank.setState("Tamil Nadu");
        bank.setDistrict("Chennai");
        bank.setCity("Chennai Central");
        bank.setStatus(BankStatus.VERIFIED);
        bank.setActive(true);
        bank = bloodBankRepository.save(bank);

        BloodStock stock = new BloodStock();
        stock.setBloodBank(bank);
        stock.setBloodGroup(BloodGroup.O_POSITIVE);
        stock.setUnits(15);
        bloodStockRepository.save(stock);

        mockMvc.perform(get("/blood-availability"))
                .andExpect(status().isOk())
                .andExpect(view().name("blood-availability"))
                .andExpect(content().string(containsString("City Red Cross Blood Bank")))
                .andExpect(content().string(containsString("15")));
    }
}
