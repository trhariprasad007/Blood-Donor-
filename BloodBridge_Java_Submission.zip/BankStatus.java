package com.bloodbridge.enums;

/**
 * Lifecycle status of a blood bank record.
 *
 * State transitions:
 *   PENDING → VERIFIED (admin verifies)
 *   PENDING → REJECTED (admin rejects)
 *   VERIFIED → INACTIVE (admin deactivates)
 *   REJECTED → PENDING (admin reconsiders)
 */
public enum BankStatus {
    PENDING("Pending Verification"),
    VERIFIED("Verified"),
    REJECTED("Rejected"),
    INACTIVE("Inactive");

    private final String displayName;

    BankStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
