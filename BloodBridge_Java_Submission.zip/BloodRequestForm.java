package com.bloodbridge.dto;

import com.bloodbridge.enums.BloodGroup;
import jakarta.validation.constraints.*;

/**
 * Form object for blood request submission by the public.
 * All contact fields are PRIVATE and never shown publicly.
 */
public class BloodRequestForm {

    @NotBlank(message = "Your name is required.")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters.")
    @Pattern(regexp = "^[a-zA-Z\\s.'-]+$", message = "Name contains invalid characters.")
    private String requesterName;

    @NotNull(message = "Blood group is required.")
    private BloodGroup bloodGroup;

    @NotNull(message = "Number of units is required.")
    @Min(value = 1, message = "At least 1 unit must be requested.")
    @Max(value = 20, message = "Cannot request more than 20 units at once.")
    private Integer unitsRequired;

    @NotBlank(message = "State is required.")
    @Size(max = 100, message = "State name is too long.")
    private String state;

    @NotBlank(message = "District is required.")
    @Size(max = 100, message = "District name is too long.")
    private String district;

    @NotBlank(message = "City or hospital locality is required.")
    @Size(max = 100, message = "City name is too long.")
    private String city;

    @Size(max = 200, message = "Hospital name is too long.")
    private String hospitalName;

    /** Optional ISO datetime string for required-by date */
    private String requiredByStr;

    @NotBlank(message = "Contact phone number is required.")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Please enter a valid 10-digit Indian mobile number.")
    private String requesterPhone;

    @Email(message = "Please enter a valid email address.")
    @Size(max = 150, message = "Email address is too long.")
    private String requesterEmail;

    @Size(max = 1000, message = "Notes are too long (max 1000 characters).")
    private String additionalNotes;

    // ========== Getters and Setters ==========

    public String getRequesterName() { return requesterName; }
    public void setRequesterName(String requesterName) { this.requesterName = requesterName; }

    public BloodGroup getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(BloodGroup bloodGroup) { this.bloodGroup = bloodGroup; }

    public Integer getUnitsRequired() { return unitsRequired; }
    public void setUnitsRequired(Integer unitsRequired) { this.unitsRequired = unitsRequired; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getHospitalName() { return hospitalName; }
    public void setHospitalName(String hospitalName) { this.hospitalName = hospitalName; }

    public String getRequiredByStr() { return requiredByStr; }
    public void setRequiredByStr(String requiredByStr) { this.requiredByStr = requiredByStr; }

    public String getRequesterPhone() { return requesterPhone; }
    public void setRequesterPhone(String requesterPhone) { this.requesterPhone = requesterPhone; }

    public String getRequesterEmail() { return requesterEmail; }
    public void setRequesterEmail(String requesterEmail) { this.requesterEmail = requesterEmail; }

    public String getAdditionalNotes() { return additionalNotes; }
    public void setAdditionalNotes(String additionalNotes) { this.additionalNotes = additionalNotes; }
}
