package com.bloodbridge.service;

import com.bloodbridge.dto.BloodRequestForm;
import com.bloodbridge.entity.BloodRequest;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.RequestStatus;
import com.bloodbridge.exception.BusinessRuleException;
import com.bloodbridge.exception.ResourceNotFoundException;
import com.bloodbridge.repository.BloodRequestRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;

/**
 * Business logic for blood request management.
 *
 * IMPORTANT:
 * - All new requests start as PENDING
 * - Only valid status transitions are allowed (see RequestStatus.canTransitionTo)
 * - Request details and contact info are NEVER publicly accessible
 * - Submitting a request does NOT deduct or reserve blood stock
 */
@Service
public class BloodRequestService {

    private static final Logger logger = LoggerFactory.getLogger(BloodRequestService.class);

    private final BloodRequestRepository bloodRequestRepository;
    private final AuditLogService auditLogService;

    public BloodRequestService(BloodRequestRepository bloodRequestRepository,
                                AuditLogService auditLogService) {
        this.bloodRequestRepository = bloodRequestRepository;
        this.auditLogService = auditLogService;
    }

    // ============================================================
    // PUBLIC METHODS
    // ============================================================

    /**
     * Submit a blood request from the public form.
     * Always creates a new PENDING request.
     */
    @Transactional
    public Long submitRequest(BloodRequestForm form) {
        return submitRequest(form, null);
    }

    @Transactional
    public Long submitRequest(BloodRequestForm form, Long userId) {
        BloodRequest request = new BloodRequest();
        request.setUserId(userId);
        request.setRequesterName(form.getRequesterName().trim());
        request.setBloodGroup(form.getBloodGroup());
        request.setUnitsRequired(form.getUnitsRequired());
        request.setState(form.getState().trim());
        request.setDistrict(form.getDistrict().trim());
        request.setCity(form.getCity().trim());
        request.setHospitalName(form.getHospitalName() != null ? form.getHospitalName().trim() : null);
        request.setRequesterPhone(form.getRequesterPhone().trim());
        request.setRequesterEmail(form.getRequesterEmail() != null ? form.getRequesterEmail().trim() : null);
        request.setAdditionalNotes(form.getAdditionalNotes() != null ? form.getAdditionalNotes().trim() : null);

        // Parse optional required-by datetime
        if (StringUtils.hasText(form.getRequiredByStr())) {
            try {
                request.setRequiredBy(LocalDateTime.parse(form.getRequiredByStr()));
            } catch (DateTimeParseException e) {
                // Non-critical: just skip if format is wrong
                logger.warn("Could not parse required-by datetime: {}", form.getRequiredByStr());
            }
        }

        // Always start as PENDING
        request.setStatus(RequestStatus.PENDING);

        BloodRequest saved = bloodRequestRepository.save(request);
        logger.info("Blood request submitted: ID={}, bloodGroup={}, city={}",
                saved.getId(), saved.getBloodGroup(), saved.getCity());
        return saved.getId();
    }

    @Transactional(readOnly = true)
    public java.util.List<BloodRequest> findByUserId(Long userId) {
        return bloodRequestRepository.findByUserIdOrderBySubmittedAtDesc(userId);
    }

    // ============================================================
    // ADMIN METHODS
    // ============================================================

    /**
     * Get a request for admin review (includes private contact details).
     * ONLY call from admin-protected controllers.
     */
    @Transactional(readOnly = true)
    public BloodRequest getForAdmin(Long id) {
        return bloodRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Blood request", id));
    }

    /**
     * List requests for admin with optional filters.
     */
    @Transactional(readOnly = true)
    public Page<BloodRequest> findAllForAdmin(RequestStatus status, BloodGroup bloodGroup, int page) {
        Pageable pageable = PageRequest.of(Math.max(0, page), 20);
        return bloodRequestRepository.findAllFiltered(status, bloodGroup, pageable);
    }

    /**
     * Update request status through a valid transition.
     * Invalid transitions are rejected.
     */
    @Transactional
    public void updateStatus(Long id, RequestStatus newStatus,
                              String adminNotes, String adminUsername) {
        BloodRequest request = getForAdmin(id);
        RequestStatus currentStatus = request.getStatus();

        if (!currentStatus.canTransitionTo(newStatus)) {
            throw new BusinessRuleException(
                    "Cannot transition from " + currentStatus.getDisplayName() +
                    " to " + newStatus.getDisplayName() + ".");
        }

        request.setStatus(newStatus);
        if (StringUtils.hasText(adminNotes)) {
            request.setAdminNotes(adminNotes);
        }
        bloodRequestRepository.save(request);

        auditLogService.log(adminUsername, "REQUEST_STATUS_UPDATED", "BLOOD_REQUEST", id,
                "Request ID=" + id + " status: " +
                currentStatus.getDisplayName() + " → " + newStatus.getDisplayName());
    }

    // ============================================================
    // DASHBOARD STATISTICS
    // ============================================================

    public long countPending() { return bloodRequestRepository.countByStatus(RequestStatus.PENDING); }
    public long countActive() { return bloodRequestRepository.countActive(); }
    public long countTotal() { return bloodRequestRepository.count(); }
}
