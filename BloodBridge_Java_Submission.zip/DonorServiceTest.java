package com.bloodbridge.service;

import com.bloodbridge.dto.DonorRegistrationForm;
import com.bloodbridge.dto.DonorPublicView;
import com.bloodbridge.entity.Donor;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.DonorStatus;
import com.bloodbridge.repository.DonorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class DonorServiceTest {

    @Autowired
    private DonorService donorService;

    @Autowired
    private DonorRepository donorRepository;

    private DonorRegistrationForm createValidForm() {
        DonorRegistrationForm form = new DonorRegistrationForm();
        form.setFullName("Ramesh Kumar");
        form.setBloodGroup(BloodGroup.O_POSITIVE);
        form.setAge(26);
        form.setState("Tamil Nadu");
        form.setDistrict("Chennai");
        form.setCity("Adyar");
        form.setPhone("9876543210");
        form.setEmail("ramesh@example.com");
        form.setAvailable(true);
        form.setConsentDataProcessing(true);
        form.setConsentPublicListing(true);
        form.setInformationAccurateConfirmation(true);
        return form;
    }

    @Test
    @DisplayName("Valid registration starts as PENDING and persists")
    void testRegisterDonorStartsPending() {
        DonorRegistrationForm form = createValidForm();
        Long id = donorService.registerDonor(form);

        assertNotNull(id);
        Donor saved = donorRepository.findById(id).orElseThrow();
        assertEquals(DonorStatus.PENDING, saved.getStatus());
        assertEquals("Ramesh Kumar", saved.getFullName());
        assertTrue(saved.getConsentPublicListing());
    }

    @Test
    @DisplayName("Unverified donor does not appear in public search")
    void testUnverifiedDonorNotInPublicSearch() {
        DonorRegistrationForm form = createValidForm();
        donorService.registerDonor(form);

        Page<DonorPublicView> results = donorService.searchPublicDonors(
                BloodGroup.O_POSITIVE, "Tamil Nadu", "Chennai", "Adyar", 0);

        assertTrue(results.getContent().stream().noneMatch(d -> d.getDisplayName().startsWith("Ramesh")));
    }

    @Test
    @DisplayName("Verified donor with public consent appears in public search with safe display name")
    void testVerifiedDonorWithConsentAppearsPublicly() {
        DonorRegistrationForm form = createValidForm();
        Long id = donorService.registerDonor(form);

        donorService.verifyDonor(id, "admin", "Identity checked");

        Page<DonorPublicView> results = donorService.searchPublicDonors(
                BloodGroup.O_POSITIVE, "Tamil Nadu", "Chennai", "Adyar", 0);

        assertEquals(1, results.getTotalElements());
        DonorPublicView view = results.getContent().get(0);
        assertEquals("Ramesh K.", view.getDisplayName());
        assertEquals(BloodGroup.O_POSITIVE, view.getBloodGroup());
    }

    @Test
    @DisplayName("Donor without public consent never appears in public search even when verified")
    void testVerifiedDonorWithoutConsentExcluded() {
        DonorRegistrationForm form = createValidForm();
        form.setConsentPublicListing(false);
        Long id = donorService.registerDonor(form);

        donorService.verifyDonor(id, "admin", "Approved");

        Page<DonorPublicView> results = donorService.searchPublicDonors(
                BloodGroup.O_POSITIVE, "Tamil Nadu", "Chennai", "Adyar", 0);

        assertEquals(0, results.getTotalElements());
    }

    @Test
    @DisplayName("Deactivating donor removes them from public search")
    void testDeactivationRemovesPublicListing() {
        DonorRegistrationForm form = createValidForm();
        Long id = donorService.registerDonor(form);
        donorService.verifyDonor(id, "admin", "Approved");

        // Verify initially visible
        assertEquals(1, donorService.searchPublicDonors(BloodGroup.O_POSITIVE, null, null, null, 0).getTotalElements());

        // Deactivate
        donorService.deactivateDonor(id, "admin", "User requested removal");

        // Verify no longer visible
        assertEquals(0, donorService.searchPublicDonors(BloodGroup.O_POSITIVE, null, null, null, 0).getTotalElements());
    }
}
