package com.bloodbridge.security;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class SecurityIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Public homepage is accessible without login")
    void testPublicHomepageAccessible() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Public donor search is accessible without login")
    void testPublicDonorSearchAccessible() throws Exception {
        mockMvc.perform(get("/donors"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Admin dashboard redirects anonymous users to login page")
    void testAdminDashboardProtected() throws Exception {
        mockMvc.perform(get("/admin/dashboard"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("**/admin/login"));
    }

    @Test
    @DisplayName("Admin POST endpoints reject unauthenticated users")
    void testAdminPostProtected() throws Exception {
        mockMvc.perform(post("/admin/donors/1/verify").with(csrf()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("**/admin/login"));
    }

    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    @DisplayName("Authenticated ADMIN can access admin dashboard")
    void testAuthenticatedAdminCanAccessDashboard() throws Exception {
        mockMvc.perform(get("/admin/dashboard"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    @DisplayName("Authenticated ADMIN can access blood banks list without 500 error")
    void testAuthenticatedAdminCanAccessBloodBanksList() throws Exception {
        mockMvc.perform(get("/admin/blood-banks"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/blood-banks/list"));
    }
}
