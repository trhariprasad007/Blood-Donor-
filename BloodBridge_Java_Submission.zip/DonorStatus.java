package com.bloodbridge.enums;

/**
 * Lifecycle status of a donor registration record.
 *
 * State transitions:
 *   PENDING → VERIFIED (admin approves)
 *   PENDING → REJECTED (admin rejects)
 *   VERIFIED → INACTIVE (admin deactivates or donor requests removal)
 *   REJECTED → PENDING (admin reconsiders)
 */
public enum DonorStatus {
    PENDING("Pending Review"),
    VERIFIED("Verified"),
    REJECTED("Rejected"),
    INACTIVE("Inactive");

    private final String displayName;

    DonorStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
