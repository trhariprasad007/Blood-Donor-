package com.bloodbridge.controller;

import com.bloodbridge.dto.DonorPublicView;
import com.bloodbridge.dto.DonorRegistrationForm;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.service.DonorService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Public donor search and registration controller.
 * Returns DonorPublicView — never exposes private entity fields.
 */
@Controller
@RequestMapping("/donors")
public class DonorController {

    private final DonorService donorService;

    public DonorController(DonorService donorService) {
        this.donorService = donorService;
    }

    // ============================================================
    // DONOR SEARCH (public)
    // ============================================================

    @GetMapping
    public String searchDonors(
            @RequestParam(required = false) BloodGroup bloodGroup,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) String district,
            @RequestParam(required = false) String city,
            @RequestParam(defaultValue = "0") int page,
            Model model) {

        Page<DonorPublicView> donors = donorService.searchPublicDonors(
                bloodGroup, state, district, city, page);

        model.addAttribute("donors", donors);
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("selectedBloodGroup", bloodGroup);
        model.addAttribute("selectedState", state);
        model.addAttribute("selectedDistrict", district);
        model.addAttribute("selectedCity", city);
        model.addAttribute("currentPage", page);
        model.addAttribute("pageTitle", "Find Blood Donors — BloodBridge");
        return "donors/search";
    }

    // ============================================================
    // DONOR REGISTRATION (public)
    // ============================================================

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("registrationForm", new DonorRegistrationForm());
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("pageTitle", "Register as a Blood Donor — BloodBridge");
        return "donors/register";
    }

    @PostMapping("/register")
    public String submitRegistration(
            @Valid @ModelAttribute("registrationForm") DonorRegistrationForm form,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            // Return to form with errors preserved (PRG not applied on validation failure)
            model.addAttribute("bloodGroups", BloodGroup.values());
            model.addAttribute("pageTitle", "Register as a Blood Donor — BloodBridge");
            return "donors/register";
        }

        Long donorId = donorService.registerDonor(form);

        // Post-Redirect-Get pattern to prevent duplicate submissions
        redirectAttributes.addFlashAttribute("successMessage",
                "Thank you for registering! Your submission (reference: #" + donorId + ") " +
                "has been received and is pending review by our team.");
        return "redirect:/donors/register/success";
    }

    @GetMapping("/register/success")
    public String registrationSuccess(Model model) {
        model.addAttribute("pageTitle", "Registration Submitted — BloodBridge");
        return "donors/register-success";
    }
}
