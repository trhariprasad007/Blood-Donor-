package com.bloodbridge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * BloodBridge Application Entry Point
 *
 * BloodBridge is a college demonstration project for a
 * Blood Donor Finder and Blood Bank Availability Management System.
 *
 * This application is for educational purposes only and is not
 * connected to real hospitals, government databases, or emergency services.
 */
@SpringBootApplication
public class BloodBridgeApplication {

    public static void main(String[] args) {
        SpringApplication.run(BloodBridgeApplication.class, args);
    }
}
