package com.bloodbridge.service;

import com.bloodbridge.dto.BloodStockForm;
import com.bloodbridge.entity.BloodBank;
import com.bloodbridge.entity.BloodStock;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.exception.BusinessRuleException;
import com.bloodbridge.exception.ResourceNotFoundException;
import com.bloodbridge.repository.BloodBankRepository;
import com.bloodbridge.repository.BloodStockRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Business logic for blood stock management.
 *
 * IMPORTANT RULES:
 * - One record per blood bank + blood group (enforced by DB and service)
 * - Units must always be >= 0
 * - Stock is manually updated by administrators only
 * - Submitting a blood request does NOT deduct stock
 * - All successful updates refresh the updatedAt timestamp (via @PreUpdate)
 */
@Service
public class BloodStockService {

    private static final Logger logger = LoggerFactory.getLogger(BloodStockService.class);
    private static final int DEFAULT_PAGE_SIZE = 20;

    private final BloodStockRepository bloodStockRepository;
    private final BloodBankRepository bloodBankRepository;
    private final AuditLogService auditLogService;

    public BloodStockService(BloodStockRepository bloodStockRepository,
                              BloodBankRepository bloodBankRepository,
                              AuditLogService auditLogService) {
        this.bloodStockRepository = bloodStockRepository;
        this.bloodBankRepository = bloodBankRepository;
        this.auditLogService = auditLogService;
    }

    // ============================================================
    // PUBLIC METHODS
    // ============================================================

    /**
     * Public blood availability view.
     * Only shows stock from VERIFIED and active blood banks.
     */
    @Transactional(readOnly = true)
    public Page<BloodStock> findPublicAvailability(BloodGroup bloodGroup,
                                                    String state, String district, int page) {
        Pageable pageable = PageRequest.of(Math.max(0, page), DEFAULT_PAGE_SIZE);
        return bloodStockRepository.findPublicAvailability(
                bloodGroup,
                normalizeFilter(state),
                normalizeFilter(district),
                pageable);
    }

    /**
     * Get all stock for a specific verified blood bank (for bank detail page).
     */
    @Transactional(readOnly = true)
    public List<BloodStock> getStockForPublicBank(Long bankId) {
        BloodBank bank = bloodBankRepository.findById(bankId)
                .orElseThrow(() -> new ResourceNotFoundException("Blood bank", bankId));
        if (!bank.isPubliclyVisible()) {
            return List.of(); // empty list for non-public banks
        }
        return bloodStockRepository.findByBloodBankOrderByBloodGroupAsc(bank);
    }

    // ============================================================
    // ADMIN METHODS
    // ============================================================

    /**
     * Get stock for a specific bank (admin view, any bank regardless of status).
     */
    @Transactional(readOnly = true)
    public List<BloodStock> getStockForBank(Long bankId) {
        BloodBank bank = bloodBankRepository.findById(bankId)
                .orElseThrow(() -> new ResourceNotFoundException("Blood bank", bankId));
        return bloodStockRepository.findByBloodBankOrderByBloodGroupAsc(bank);
    }

    /**
     * Get a specific stock record by ID (admin only).
     */
    @Transactional(readOnly = true)
    public BloodStock getById(Long id) {
        return bloodStockRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Blood stock record", id));
    }

    /**
     * Add a new stock record for a bank + blood group combination.
     * Rejects duplicate combinations and negative units.
     */
    @Transactional
    public BloodStock addStockRecord(BloodStockForm form, String adminUsername) {
        validateUnits(form.getUnits());

        BloodBank bank = bloodBankRepository.findById(form.getBloodBankId())
                .orElseThrow(() -> new ResourceNotFoundException("Blood bank", form.getBloodBankId()));

        // Check for duplicate
        if (bloodStockRepository.existsByBloodBankAndBloodGroup(bank, form.getBloodGroup())) {
            throw new BusinessRuleException(
                    "A stock record for " + form.getBloodGroup().getDisplayName() +
                    " already exists for this blood bank. Use the update function instead.");
        }

        BloodStock stock = new BloodStock();
        stock.setBloodBank(bank);
        stock.setBloodGroup(form.getBloodGroup());
        stock.setUnits(form.getUnits());
        stock.setAdminRemarks(form.getAdminRemarks());

        try {
            BloodStock saved = bloodStockRepository.save(stock);
            auditLogService.log(adminUsername, "STOCK_CREATED", "BLOOD_STOCK", saved.getId(),
                    "Stock created: " + bank.getName() + " - " +
                    form.getBloodGroup().getDisplayName() + " = " + form.getUnits() + " units");
            return saved;
        } catch (DataIntegrityViolationException ex) {
            throw new BusinessRuleException("A stock record for this blood group already exists at this bank.");
        }
    }

    /**
     * Update an existing stock record.
     * Negative units are rejected at service AND entity level.
     * Transaction ensures atomicity — a failed update does not corrupt existing records.
     */
    @Transactional
    public void updateStockRecord(Long id, int newUnits, String adminRemarks, String adminUsername) {
        validateUnits(newUnits);

        BloodStock stock = getById(id);
        int oldUnits = stock.getUnits();
        stock.setUnits(newUnits);
        if (adminRemarks != null) {
            stock.setAdminRemarks(adminRemarks);
        }
        // @PreUpdate will automatically refresh updatedAt
        bloodStockRepository.save(stock);

        auditLogService.log(adminUsername, "STOCK_UPDATED", "BLOOD_STOCK", id,
                "Stock updated: " + stock.getBloodBank().getName() + " - " +
                stock.getBloodGroup().getDisplayName() +
                ": " + oldUnits + " → " + newUnits + " units");
    }

    // ============================================================
    // DASHBOARD STATISTICS
    // ============================================================

    public long countTotal() { return bloodStockRepository.countAll(); }

    // ============================================================
    // HELPERS
    // ============================================================

    private void validateUnits(int units) {
        if (units < 0) {
            throw new BusinessRuleException("Blood stock units cannot be negative. Provided: " + units);
        }
    }

    private String normalizeFilter(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim();
    }
}
