package com.bloodbridge.entity;

import com.bloodbridge.enums.BankStatus;
import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a blood bank in the directory.
 * Only VERIFIED and active banks are shown to the public.
 *
 * IMPORTANT: Do not use real institution names, real phone numbers,
 * or fabricated licence numbers. Use clearly fictional demonstration data.
 */
@Entity
@Table(name = "blood_banks", indexes = {
        @Index(name = "idx_bank_state", columnList = "state"),
        @Index(name = "idx_bank_district", columnList = "district"),
        @Index(name = "idx_bank_status", columnList = "status")
})
public class BloodBank {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false, length = 200)
    private String name;

    @Column(name = "address", nullable = false, length = 500)
    private String address;

    @Column(name = "state", nullable = false, length = 100)
    private String state;

    @Column(name = "district", nullable = false, length = 100)
    private String district;

    @Column(name = "city", nullable = false, length = 100)
    private String city;

    /** Publicly displayable contact phone (authorized by the bank) */
    @Column(name = "contact_phone", length = 15)
    private String contactPhone;

    /** Publicly displayable contact email */
    @Column(name = "contact_email", length = 150)
    private String contactEmail;

    /** Official website URL of the blood bank */
    @Column(name = "website_url", length = 300)
    private String websiteUrl;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(name = "status", nullable = false, length = 20)
    private BankStatus status = BankStatus.PENDING;

    @Column(name = "active", nullable = false)
    private Boolean active = true;

    @Column(name = "admin_notes", length = 500)
    private String adminNotes;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    /** Blood stock records associated with this bank */
    @OneToMany(mappedBy = "bloodBank", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<BloodStock> stockRecords = new ArrayList<>();

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (status == null) status = BankStatus.PENDING;
        if (active == null) active = true;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    /**
     * Returns true if this bank should be shown in the public directory.
     */
    public boolean isPubliclyVisible() {
        return BankStatus.VERIFIED.equals(status) && Boolean.TRUE.equals(active);
    }

    // ========== Getters and Setters ==========

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getContactPhone() { return contactPhone; }
    public void setContactPhone(String contactPhone) { this.contactPhone = contactPhone; }

    public String getContactEmail() { return contactEmail; }
    public void setContactEmail(String contactEmail) { this.contactEmail = contactEmail; }

    public String getWebsiteUrl() { return websiteUrl; }
    public void setWebsiteUrl(String websiteUrl) { this.websiteUrl = websiteUrl; }

    public BankStatus getStatus() { return status; }
    public void setStatus(BankStatus status) { this.status = status; }

    public Boolean getActive() { return active; }
    public void setActive(Boolean active) { this.active = active; }

    public String getAdminNotes() { return adminNotes; }
    public void setAdminNotes(String adminNotes) { this.adminNotes = adminNotes; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public List<BloodStock> getStockRecords() { return stockRecords; }
    public void setStockRecords(List<BloodStock> stockRecords) { this.stockRecords = stockRecords; }
}
