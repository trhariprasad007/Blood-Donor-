package com.bloodbridge.controller;

import com.bloodbridge.dto.BloodRequestForm;
import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.service.BloodRequestService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Public blood request submission controller.
 * Request details and contact info are NEVER accessible publicly.
 */
@Controller
@RequestMapping("/blood-requests")
public class BloodRequestController {

    private final BloodRequestService bloodRequestService;

    public BloodRequestController(BloodRequestService bloodRequestService) {
        this.bloodRequestService = bloodRequestService;
    }

    @GetMapping("/new")
    public String showForm(Model model) {
        model.addAttribute("requestForm", new BloodRequestForm());
        model.addAttribute("bloodGroups", BloodGroup.values());
        model.addAttribute("pageTitle", "Request Blood — BloodBridge");
        return "blood-requests/new";
    }

    @PostMapping("/submit")
    public String submit(
            @Valid @ModelAttribute("requestForm") BloodRequestForm form,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("bloodGroups", BloodGroup.values());
            model.addAttribute("pageTitle", "Request Blood — BloodBridge");
            return "blood-requests/new";
        }

        Long requestId = bloodRequestService.submitRequest(form);

        // PRG to prevent duplicate submission on refresh
        redirectAttributes.addFlashAttribute("successMessage",
                "Your blood request (reference: #" + requestId + ") has been received. " +
                "Our team will review it shortly.");
        return "redirect:/blood-requests/confirmation";
    }

    @GetMapping("/confirmation")
    public String confirmation(Model model) {
        model.addAttribute("pageTitle", "Request Submitted — BloodBridge");
        return "blood-requests/confirmation";
    }
}
