package com.bloodbridge.service;

import com.bloodbridge.dto.UserRegisterForm;
import com.bloodbridge.entity.AppUser;
import com.bloodbridge.enums.UserRole;
import com.bloodbridge.exception.BusinessRuleException;
import com.bloodbridge.repository.AppUserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class UserService {

    private final AppUserRepository appUserRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(AppUserRepository appUserRepository, PasswordEncoder passwordEncoder) {
        this.appUserRepository = appUserRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public AppUser register(UserRegisterForm form, UserRole role) {
        if (appUserRepository.existsByUsername(form.getUsername().trim())) {
            throw new BusinessRuleException("Username '" + form.getUsername() + "' is already taken.");
        }

        AppUser user = new AppUser();
        user.setUsername(form.getUsername().trim());
        user.setPasswordHash(passwordEncoder.encode(form.getPassword()));
        user.setRole(role);
        user.setFullName(form.getFullName().trim());
        user.setEmail(form.getEmail() != null ? form.getEmail().trim() : null);
        user.setPhone(form.getPhone() != null ? form.getPhone().trim() : null);
        user.setActive(true);

        return appUserRepository.save(user);
    }

    public Optional<AppUser> findByUsername(String username) {
        return appUserRepository.findByUsername(username);
    }
}
