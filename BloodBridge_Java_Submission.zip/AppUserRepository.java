package com.bloodbridge.repository;

import com.bloodbridge.entity.AppUser;
import com.bloodbridge.enums.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AppUserRepository extends JpaRepository<AppUser, Long> {

    Optional<AppUser> findByUsername(String username);

    Optional<AppUser> findByUsernameAndRole(String username, UserRole role);

    boolean existsByUsername(String username);
}
