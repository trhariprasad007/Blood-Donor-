package com.bloodbridge.entity;

import com.bloodbridge.enums.BloodGroup;
import com.bloodbridge.enums.DonorStatus;
import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.time.LocalDateTime;

/**
 * Represents a blood donor registration.
 *
 * PRIVACY RULES:
 * - phone and email are NEVER exposed in public responses
 * - A donor is publicly searchable ONLY when ALL of these are true:
 *   1. status == VERIFIED
 *   2. consentPublicListing == true
 *   3. available == true
 *   4. active == true
 */
@Entity
@Table(name = "donors", indexes = {
        @Index(name = "idx_donor_blood_group", columnList = "blood_group"),
        @Index(name = "idx_donor_state", columnList = "state"),
        @Index(name = "idx_donor_district", columnList = "district"),
        @Index(name = "idx_donor_status", columnList = "status")
})
public class Donor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Display name only - never expose full name publicly */
    @Column(name = "full_name", nullable = false, length = 100)
    private String fullName;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(name = "blood_group", nullable = false, length = 20)
    private BloodGroup bloodGroup;

    @Column(name = "age", nullable = false)
    private Integer age;

    @Column(name = "state", nullable = false, length = 100)
    private String state;

    @Column(name = "district", nullable = false, length = 100)
    private String district;

    @Column(name = "city", nullable = false, length = 100)
    private String city;

    /** PRIVATE - never expose in public responses */
    @Column(name = "phone", nullable = false, length = 15)
    private String phone;

    /** PRIVATE - never expose in public responses */
    @Column(name = "email", length = 150)
    private String email;

    @Column(name = "available", nullable = false)
    private Boolean available = true;

    @Column(name = "consent_data_processing", nullable = false)
    private Boolean consentDataProcessing = false;

    @Column(name = "consent_public_listing", nullable = false)
    private Boolean consentPublicListing = false;

    @Column(name = "information_accurate_confirmation", nullable = false)
    private Boolean informationAccurateConfirmation = false;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(name = "status", nullable = false, length = 20)
    private DonorStatus status = DonorStatus.PENDING;

    @Column(name = "active", nullable = false)
    private Boolean active = true;

    @Column(name = "admin_notes", length = 500)
    private String adminNotes;

    @Column(name = "registered_at", nullable = false, updatable = false)
    private LocalDateTime registeredAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @Column(name = "user_id")
    private Long userId;

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    @PrePersist
    protected void onCreate() {
        registeredAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (status == null) status = DonorStatus.PENDING;
        if (available == null) available = true;
        if (active == null) active = true;
        if (consentDataProcessing == null) consentDataProcessing = false;
        if (consentPublicListing == null) consentPublicListing = false;
        if (informationAccurateConfirmation == null) informationAccurateConfirmation = false;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    /**
     * Returns true if this donor satisfies ALL conditions for public listing.
     * Used to enforce visibility rules consistently.
     */
    public boolean isPubliclyEligible() {
        return DonorStatus.VERIFIED.equals(status)
                && Boolean.TRUE.equals(consentPublicListing)
                && Boolean.TRUE.equals(available)
                && Boolean.TRUE.equals(active);
    }

    /**
     * Returns a safe public display name (first name + last initial).
     * Example: "Rajesh Kumar" → "Rajesh K."
     */
    public String getDisplayName() {
        if (fullName == null || fullName.isBlank()) return "Anonymous";
        String[] parts = fullName.trim().split("\\s+");
        if (parts.length == 1) return parts[0];
        return parts[0] + " " + parts[parts.length - 1].charAt(0) + ".";
    }

    // ========== Getters and Setters ==========

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public BloodGroup getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(BloodGroup bloodGroup) { this.bloodGroup = bloodGroup; }

    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Boolean getAvailable() { return available; }
    public void setAvailable(Boolean available) { this.available = available; }

    public Boolean getConsentDataProcessing() { return consentDataProcessing; }
    public void setConsentDataProcessing(Boolean consentDataProcessing) { this.consentDataProcessing = consentDataProcessing; }

    public Boolean getConsentPublicListing() { return consentPublicListing; }
    public void setConsentPublicListing(Boolean consentPublicListing) { this.consentPublicListing = consentPublicListing; }

    public Boolean getInformationAccurateConfirmation() { return informationAccurateConfirmation; }
    public void setInformationAccurateConfirmation(Boolean informationAccurateConfirmation) { this.informationAccurateConfirmation = informationAccurateConfirmation; }

    public DonorStatus getStatus() { return status; }
    public void setStatus(DonorStatus status) { this.status = status; }

    public Boolean getActive() { return active; }
    public void setActive(Boolean active) { this.active = active; }

    public String getAdminNotes() { return adminNotes; }
    public void setAdminNotes(String adminNotes) { this.adminNotes = adminNotes; }

    public LocalDateTime getRegisteredAt() { return registeredAt; }
    public void setRegisteredAt(LocalDateTime registeredAt) { this.registeredAt = registeredAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
